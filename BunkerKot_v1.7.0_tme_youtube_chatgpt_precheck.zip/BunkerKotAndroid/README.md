# Бункер Кота v1.6.0

## Изменения
- Переработан главный экран: аккуратнее типографика, меньше визуального шума, сердце остаётся главной кнопкой.
- Убрана секция сохранённых профилей и ручной импорт. Список серверов загружается из выбранной подписки и хранится только в памяти приложения.
- Добавлено переключение между белым и чёрным списками, обновление списка и поиск серверов.
- Поддерживаются обычные текстовые VLESS-списки и Base64-encoded subscriptions.
- Подключение/отключение управляется Android VpnService и sing-box/libbox. Статус меняется по событию VPN-сервиса, а не только по нажатию кнопки.
- Добавлены ABI-specific APK builds (`arm64-v8a`, `armeabi-v7a`, `x86_64`), чтобы не включать нативные библиотеки всех архитектур в один тяжёлый APK.

## Подписки
- White: `https://hub.mos.ru/akelladejavu/bunker/-/raw/main/WHITE_LIST.txt`
- Black: `https://hub.mos.ru/akelladejavu/bunker/-/raw/main/BLACK_LIST.txt`

Если подписка недоступна из сети устройства, приложение покажет HTTP/сетевую ошибку; в этой среде не удалось проверить доступность адресов, поэтому загрузку нужно подтвердить на устройстве.

## Движок
Зависимость: `com.github.singbox-android:libbox:1.14.3`. VLESS-конфигурации преобразуются в sing-box JSON. Поддержка отдельных транспортов и параметров зависит от URI сервера; успешная сборка не гарантирует подключение к каждому узлу.

Перед публичным распространением libbox необходимо выполнить условия его GPL-3.0 лицензии, включая предоставление соответствующего исходного кода и уведомлений.

## Сборка
Из каталога проекта: `gradle :app:assembleDebug`. В GitHub Actions собираются отдельные APK для указанных ABI. Для большинства современных Android-телефонов обычно нужен `arm64-v8a`; не устанавливай APK для другой архитектуры.

Minimum Android version: Android 7.0 (API 24).


## v1.6.0 — stability pass
- Subscription refresh retries once, bypasses HTTP cache, and preserves the last successful list if a refresh fails. Successful white/black lists are cached separately.
- Automatic list refresh every 30 minutes while the app process is active.
- Automatic TCP connect-time checks for server endpoints every 90 seconds; this is a reachability/handshake latency check, not a measurement through the VPN tunnel.
- VPN teardown is guarded against recursive `serviceStop` / `closeService` callbacks, and start failures are surfaced with a more specific status message.
- Corrected libbox interface string iterator length reporting, enabled Android interface auto-detection, and reduced TUN MTU to 1400.
- Simplified typography and made heart-button placement responsive to hero image dimensions.
- Native libraries use compressed APK packaging to reduce download size where possible.


## v1.6.0
- Убраны встроенные внешние WHITE_LIST/BLACK_LIST URL.
- Белый и чёрный списки теперь локальные и независимые.
- Добавление HTTPS-подписок и отдельных VLESS-ссылок вручную.
- HTTPS GET URL TEST с кодом ответа и временем.
- Убран TCP ping.
- Исправлены системные отступы верхней панели под статус-бар Android.
- Локальное сохранение источников и последнего списка серверов.


## v1.6.1 fixes

- Migrated DNS server configuration to the sing-box 1.14+ format (`type: local`); removed the obsolete DNS outbound.
- Changed the main URL TEST button to issue an HTTPS GET to `generate_204` through the currently active VPN tunnel and show HTTP status plus elapsed time.
- Kept subscription-source HTTPS checks separate from VPN tunnel testing.
- Periodic URL TEST now checks the active VPN tunnel only when connected.


## v1.7.0 server precheck
- Before connection, the app can temporarily bring up each VLESS server and test HTTPS through that exact tunnel.
- Checks `https://t.me/`, YouTube `https://www.youtube.com/generate_204`, and `https://chatgpt.com/`.
- A transport/TLS failure or HTTP 5xx removes the server from the local cache; a 4xx response still counts as destination reachability.
- After the pass, only servers that answered all three destinations remain.
- This is HTTPS reachability/latency, not a raw TCP ping.
