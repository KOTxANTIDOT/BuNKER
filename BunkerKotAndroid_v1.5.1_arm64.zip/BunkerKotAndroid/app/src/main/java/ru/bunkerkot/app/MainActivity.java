package ru.bunkerkot.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9, 9, 9);
    private final int PANEL = Color.rgb(22, 22, 22);
    private final int ORANGE = Color.rgb(255, 145, 35);
    private final int WHITE = Color.rgb(245, 243, 240);
    private final int MUTED = Color.rgb(153, 151, 149);
    private final int GREEN = Color.rgb(88, 210, 126);
    private static final String WHITE_URL = "https://hub.mos.ru/akelladejavu/bunker/-/raw/main/WHITE_LIST.txt";
    private static final String BLACK_URL = "https://hub.mos.ru/akelladejavu/bunker/-/raw/main/BLACK_LIST.txt";
    private static final int VPN_PERMISSION_REQUEST = 2002;
    private static final int MAX_VISIBLE_NODES = 45;

    private final List<Profile> profiles = new ArrayList<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private int selected = -1;
    private boolean blackListSelected = false;
    private boolean vpnConnected = false;
    private boolean loading = false;
    private String pendingVpnConfig;
    private String searchText = "";

    private TextView status, statusSub, cfgName, nodeCount, listModeLabel, connectButton;
    private LinearLayout nodeList;
    private EditText searchBox;
    private Button whiteButton, blackButton, refreshButton;
    private ImageView heroArtwork;

    private static class Profile {
        final String name;
        final String uri;
        Profile(String name, String uri) { this.name = name; this.uri = uri; }
    }

    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!BunkerVpnService.ACTION_STATE.equals(intent.getAction())) return;
            vpnConnected = intent.getBooleanExtra(BunkerVpnService.EXTRA_CONNECTED, false);
            updateVpnUi(intent.getStringExtra(BunkerVpnService.EXTRA_MESSAGE));
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(22));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher_round);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(11), 0, 0, 0);
        TextView title = text("БУНКЕР КОТА", 22, WHITE);
        title.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        title.setLetterSpacing(0.025f);
        titles.addView(title);
        TextView subtitle = text("VPN   •   PROXY   •   TELEGRAM", 10, MUTED);
        subtitle.setLetterSpacing(0.055f);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView menu = text("⋮", 28, MUTED);
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu, new LinearLayout.LayoutParams(dp(30), dp(44)));
        root.addView(header);

        space(root, 12);
        LinearLayout statusCard = panel();
        statusCard.setPadding(dp(16), dp(13), dp(16), dp(13));
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.addView(text("●", 12, ORANGE), wrap());
        status = text("НЕ ПОДКЛЮЧЕНО", 17, ORANGE);
        status.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        status.setLetterSpacing(0.005f);
        status.setPadding(dp(8), 0, 0, 0);
        statusRow.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("SING-BOX", 9, MUTED);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(8), 0, dp(8), 0);
        badge.setBackgroundResource(R.drawable.bg_badge);
        statusRow.addView(badge, new LinearLayout.LayoutParams(-2, dp(26)));
        statusCard.addView(statusRow);
        space(statusCard, 6);
        statusSub = text("Загружаем белый список серверов…", 12, MUTED);
        statusCard.addView(statusSub);
        root.addView(statusCard);

        space(root, 8);
        FrameLayout hero = new FrameLayout(this);
        hero.setBackgroundColor(BG);
        heroArtwork = new ImageView(this);
        heroArtwork.setImageResource(R.drawable.cat_heart_hero);
        heroArtwork.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(heroArtwork, new FrameLayout.LayoutParams(-1, -1));
        connectButton = text("ПОДКЛЮЧИТЬ", 14, Color.rgb(34, 13, 3));
        connectButton.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        connectButton.setLetterSpacing(0.045f);
        connectButton.setGravity(Gravity.CENTER);
        connectButton.setClickable(true);
        connectButton.setFocusable(true);
        connectButton.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams heartParams = new FrameLayout.LayoutParams(dp(206), dp(50), Gravity.CENTER);
        heartParams.topMargin = dp(104);
        hero.addView(connectButton, heartParams);
        root.addView(hero, new LinearLayout.LayoutParams(-1, dp(360)));
        connectButton.setOnClickListener(v -> toggleVpn());

        space(root, 8);
        LinearLayout subs = panel();
        subs.setPadding(dp(14), dp(13), dp(14), dp(13));
        TextView subTitle = label("ПОДПИСКИ БУНКЕРА");
        subTitle.setLetterSpacing(0.06f);
        subs.addView(subTitle);
        space(subs, 9);
        LinearLayout switchRow = new LinearLayout(this);
        whiteButton = modeButton("БЕЛЫЙ СПИСОК");
        blackButton = modeButton("ЧЁРНЫЙ СПИСОК");
        switchRow.addView(whiteButton, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams blackParams = new LinearLayout.LayoutParams(0, dp(44), 1);
        blackParams.leftMargin = dp(8);
        switchRow.addView(blackButton, blackParams);
        subs.addView(switchRow);
        space(subs, 8);
        refreshButton = secondaryButton("ОБНОВИТЬ СПИСОК");
        refreshButton.setOnClickListener(v -> loadSubscription(true));
        subs.addView(refreshButton, new LinearLayout.LayoutParams(-1, dp(42)));
        space(subs, 7);
        listModeLabel = text("БЕЛЫЙ СПИСОК · 0 СЕРВЕРОВ", 10, MUTED);
        listModeLabel.setLetterSpacing(0.035f);
        subs.addView(listModeLabel);
        root.addView(subs);
        whiteButton.setOnClickListener(v -> selectList(false));
        blackButton.setOnClickListener(v -> selectList(true));

        space(root, 12);
        cfgName = text("Сервер не выбран", 16, WHITE);
        cfgName.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        root.addView(label("ТЕКУЩИЙ СЕРВЕР"));
        space(root, 4);
        root.addView(cfgName);
        space(root, 10);
        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(14);
        searchBox.setTextColor(WHITE);
        searchBox.setHintTextColor(MUTED);
        searchBox.setHint("Найти сервер по названию или адресу");
        searchBox.setPadding(dp(14), 0, dp(14), 0);
        searchBox.setBackgroundResource(R.drawable.bg_secondary);
        root.addView(searchBox, new LinearLayout.LayoutParams(-1, dp(46)));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { searchText = s.toString().trim().toLowerCase(Locale.ROOT); renderNodes(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        space(root, 7);
        nodeList = new LinearLayout(this);
        nodeList.setOrientation(LinearLayout.VERTICAL);
        root.addView(nodeList);

        space(root, 10);
        TextView footer = text("БУНКЕР КОТА  •  SING-BOX", 10, MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(0.08f);
        root.addView(footer);
        setContentView(scroll);
        updateModeButtons();
        renderNodes();
        updateVpnUi("Подключись к списку серверов Бункера.");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(vpnReceiver, new IntentFilter(BunkerVpnService.ACTION_STATE), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(vpnReceiver, new IntentFilter(BunkerVpnService.ACTION_STATE));
        loadSubscription(false);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(vpnReceiver); } catch (Exception ignored) { }
        executor.shutdownNow();
        super.onDestroy();
    }

    private void selectList(boolean useBlack) {
        if (blackListSelected == useBlack && !profiles.isEmpty()) return;
        if (vpnConnected) {
            startService(new Intent(this, BunkerVpnService.class).setAction(BunkerVpnService.ACTION_STOP));
        }
        blackListSelected = useBlack;
        profiles.clear();
        selected = -1;
        searchText = "";
        if (searchBox != null) searchBox.setText("");
        updateModeButtons();
        renderNodes();
        loadSubscription(false);
    }

    private void updateModeButtons() {
        if (whiteButton == null || blackButton == null) return;
        styleModeButton(whiteButton, !blackListSelected);
        styleModeButton(blackButton, blackListSelected);
        if (listModeLabel != null) listModeLabel.setText((blackListSelected ? "ЧЁРНЫЙ СПИСОК" : "БЕЛЫЙ СПИСОК") + " · " + profiles.size() + " СЕРВЕРОВ");
    }

    private void styleModeButton(Button button, boolean active) {
        button.setTextColor(active ? Color.BLACK : WHITE);
        button.setBackgroundResource(active ? R.drawable.bg_button : R.drawable.bg_secondary);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    private Button modeButton(String title) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackgroundResource(R.drawable.bg_secondary);
        return b;
    }

    private void loadSubscription(boolean userInitiated) {
        if (loading) return;
        loading = true;
        refreshButton.setEnabled(false);
        refreshButton.setText("ЗАГРУЗКА…");
        statusSub.setText("Получаем серверы подписки…");
        final boolean requestBlack = blackListSelected;
        final String endpoint = requestBlack ? BLACK_URL : WHITE_URL;
        executor.execute(() -> {
            List<Profile> result = new ArrayList<>();
            String error = null;
            HttpURLConnection connection = null;
            try {
                connection = (HttpURLConnection) new URL(endpoint).openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(12000);
                connection.setReadTimeout(18000);
                connection.setInstanceFollowRedirects(true);
                connection.setRequestProperty("User-Agent", "BunkerKot/1.5 Android");
                connection.setRequestProperty("Accept", "text/plain, */*");
                int code = connection.getResponseCode();
                if (code < 200 || code >= 300) throw new IllegalStateException("Сервер подписки ответил HTTP " + code);
                StringBuilder body = new StringBuilder();
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    String line;
                    while ((line = reader.readLine()) != null) body.append(line).append('\n');
                }
                String content = body.toString().trim();
                result = parseSubscription(content);
                if (result.isEmpty()) throw new IllegalStateException("В подписке не найдено VLESS-серверов");
            } catch (Exception e) {
                error = e.getMessage() == null ? "Не удалось загрузить подписку" : e.getMessage();
            } finally { if (connection != null) connection.disconnect(); }
            final List<Profile> fetched = result;
            final String failure = error;
            runOnUiThread(() -> {
                loading = false;
                refreshButton.setEnabled(true);
                refreshButton.setText("ОБНОВИТЬ СПИСОК");
                if (requestBlack != blackListSelected) {
                    loadSubscription(false);
                    return;
                }
                profiles.clear();
                profiles.addAll(fetched);
                selected = profiles.isEmpty() ? -1 : 0;
                updateModeButtons();
                renderNodes();
                if (failure == null) {
                    statusSub.setText("Список обновлён. Выбери сервер и нажми на сердце.");
                    if (userInitiated) toast("Загружено серверов: " + profiles.size());
                } else {
                    statusSub.setText(failure);
                    if (userInitiated) new AlertDialog.Builder(this).setTitle("Не удалось обновить список").setMessage(failure + "\n\nПроверь доступность подписки и попробуй ещё раз.").setPositiveButton("ОК", null).show();
                }
            });
        });
    }

    private List<Profile> parseSubscription(String source) {
        List<Profile> found = parseLines(source);
        if (!found.isEmpty()) return deduplicate(found);
        String compact = source.replaceAll("\\s+", "");
        try {
            byte[] decoded = android.util.Base64.decode(compact, android.util.Base64.DEFAULT);
            found = parseLines(new String(decoded, StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
        if (found.isEmpty()) {
            try {
                byte[] decoded = android.util.Base64.decode(compact, android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP | android.util.Base64.NO_PADDING);
                found = parseLines(new String(decoded, StandardCharsets.UTF_8));
            } catch (Exception ignored) { }
        }
        return deduplicate(found);
    }

    private List<Profile> parseLines(String text) {
        List<Profile> result = new ArrayList<>();
        for (String line : text.split("[\\r\\n]+")) {
            String uri = line.trim();
            if (!uri.toLowerCase(Locale.ROOT).startsWith("vless://")) continue;
            try {
                Uri parsed = Uri.parse(uri);
                if (parsed.getHost() == null || parsed.getPort() < 1 || parsed.getUserInfo() == null) continue;
                result.add(new Profile(extractName(uri), uri));
            } catch (Exception ignored) { }
        }
        return result;
    }

    private List<Profile> deduplicate(List<Profile> source) {
        List<Profile> result = new ArrayList<>();
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (Profile p : source) if (seen.add(p.uri)) result.add(p);
        return result;
    }

    private void renderNodes() {
        if (nodeList == null) return;
        nodeList.removeAllViews();
        if (listModeLabel != null) listModeLabel.setText((blackListSelected ? "ЧЁРНЫЙ СПИСОК" : "БЕЛЫЙ СПИСОК") + " · " + profiles.size() + " СЕРВЕРОВ");
        cfgName.setText(selected >= 0 && selected < profiles.size() ? profiles.get(selected).name : "Сервер не выбран");
        if (profiles.isEmpty()) {
            TextView empty = text(loading ? "Загружаем список…" : "Серверов пока нет. Нажми «Обновить список». ", 13, MUTED);
            empty.setPadding(dp(12), dp(14), dp(12), dp(14));
            nodeList.addView(empty);
            return;
        }
        int visible = 0;
        int matches = 0;
        for (int i = 0; i < profiles.size(); i++) {
            Profile profile = profiles.get(i);
            String haystack = (profile.name + " " + Uri.parse(profile.uri).getHost()).toLowerCase(Locale.ROOT);
            if (!searchText.isEmpty() && !haystack.contains(searchText)) continue;
            matches++;
            if (visible >= MAX_VISIBLE_NODES) continue;
            final int index = i;
            LinearLayout row = panel();
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(9), dp(12), dp(9));
            row.setBackgroundResource(i == selected ? R.drawable.bg_secondary : R.drawable.bg_panel);
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(profile.name, 13, i == selected ? ORANGE : WHITE);
            name.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            name.setMaxLines(1);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(name);
            TextView host = text(Uri.parse(profile.uri).getHost() == null ? "VLESS" : Uri.parse(profile.uri).getHost(), 10, MUTED);
            host.setMaxLines(1);
            host.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(host);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            TextView choose = text(i == selected ? "ВЫБРАН" : "ВЫБРАТЬ", 10, i == selected ? ORANGE : MUTED);
            choose.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            choose.setGravity(Gravity.CENTER);
            choose.setPadding(dp(8), dp(8), dp(4), dp(8));
            row.addView(choose, wrap());
            row.setOnClickListener(v -> { selected = index; cfgName.setText(profiles.get(index).name); renderNodes(); });
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(6);
            nodeList.addView(row, rp);
            visible++;
        }
        if (matches == 0) {
            TextView empty = text("Ничего не найдено", 13, MUTED);
            empty.setPadding(dp(12), dp(12), dp(12), dp(12));
            nodeList.addView(empty);
        } else if (matches > MAX_VISIBLE_NODES) {
            TextView more = text("Показаны первые " + MAX_VISIBLE_NODES + " из " + matches + ". Уточни поиск, чтобы найти остальные.", 11, MUTED);
            more.setPadding(dp(8), dp(8), dp(8), dp(8));
            nodeList.addView(more);
        }
    }

    private void toggleVpn() {
        if (vpnConnected) {
            startService(new Intent(this, BunkerVpnService.class).setAction(BunkerVpnService.ACTION_STOP));
            return;
        }
        if (selected < 0 || selected >= profiles.size()) {
            toast("Сначала загрузи список и выбери сервер");
            return;
        }
        try {
            pendingVpnConfig = VlessConfig.fromUri(profiles.get(selected).uri);
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
            else startVpnService(pendingVpnConfig);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Не удалось подготовить сервер")
                .setMessage(e.getMessage() == null ? "Проверь конфигурацию VLESS" : e.getMessage())
                .setPositiveButton("ОК", null).show();
        }
    }

    private void startVpnService(String config) {
        Intent intent = new Intent(this, BunkerVpnService.class)
            .setAction(BunkerVpnService.ACTION_START)
            .putExtra(BunkerVpnService.EXTRA_CONFIG, config);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        status.setText("ПОДКЛЮЧАЕМСЯ");
        status.setTextColor(ORANGE);
        statusSub.setText("Запускаем sing-box и создаём VPN-туннель…");
        connectButton.setText("ЗАПУСК…");
    }

    private void updateVpnUi(String message) {
        if (status == null || connectButton == null) return;
        if (vpnConnected) {
            status.setText("ПОДКЛЮЧЕНО");
            status.setTextColor(GREEN);
            connectButton.setText("ОТКЛЮЧИТЬ");
            statusSub.setText(message == null ? "VPN-туннель запущен." : message);
            heroArtwork.setColorFilter(Color.argb(50, 255, 130, 20), android.graphics.PorterDuff.Mode.SRC_ATOP);
        } else {
            status.setText("НЕ ПОДКЛЮЧЕНО");
            status.setTextColor(ORANGE);
            connectButton.setText("ПОДКЛЮЧИТЬ");
            statusSub.setText(message == null ? "Выбери сервер и нажми на сердце." : message);
            heroArtwork.clearColorFilter();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK && pendingVpnConfig != null) startVpnService(pendingVpnConfig);
            else toast("Для подключения нужно разрешение VPN от Android");
        }
    }

    private String extractName(String uri) {
        try {
            Uri parsed = Uri.parse(uri);
            String fragment = parsed.getFragment();
            if (fragment != null && !fragment.trim().isEmpty()) {
                String name = URLDecoder.decode(fragment, "UTF-8").trim();
                if (!name.isEmpty()) return name;
            }
            String host = parsed.getHost();
            return host == null || host.isEmpty() ? "VLESS сервер" : host;
        } catch (Exception e) { return "VLESS сервер"; }
    }

    private void showMenu() {
        String[] items = {"Обновить подписку", "О приложении"};
        new AlertDialog.Builder(this).setTitle("Бункер Кота").setItems(items, (d, which) -> {
            if (which == 0) loadSubscription(true);
            else new AlertDialog.Builder(this).setTitle("Бункер Кота · v1.5").setMessage("Клиент использует sing-box/libbox. Список серверов загружается из выбранной подписки. Успешное подключение подтверждается состоянием VPN-сервиса.").setPositiveButton("ОК", null).show();
        }).show();
    }

    private LinearLayout panel() { LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setBackgroundResource(R.drawable.bg_panel); return p; }
    private TextView label(String s) { TextView t = text(s, 10, ORANGE); t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); return t; }
    private Button secondaryButton(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(12); b.setTextColor(WHITE); b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackgroundResource(R.drawable.bg_secondary); b.setPadding(dp(8), 0, dp(8), 0); return b; }
    private TextView text(String s, float size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setFontFeatureSettings("kern"); return t; }
    private LinearLayout.LayoutParams wrap() { return new LinearLayout.LayoutParams(-2, -2); }
    private void space(LinearLayout p, int h) { View v = new View(this); p.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
