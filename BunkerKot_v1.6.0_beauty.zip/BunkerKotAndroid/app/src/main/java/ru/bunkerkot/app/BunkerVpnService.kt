package ru.bunkerkot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import io.nekohasekai.libbox.*
import java.net.NetworkInterface as JavaNetworkInterface

class BunkerVpnService : VpnService(), PlatformInterface, CommandServerHandler {
    companion object {
        const val ACTION_START = "ru.bunkerkot.app.START_VPN"
        const val ACTION_STOP = "ru.bunkerkot.app.STOP_VPN"
        const val ACTION_STATE = "ru.bunkerkot.app.VPN_STATE"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_CONNECTED = "connected"
        private const val NOTIFICATION_ID = 4201
        private const val CHANNEL_ID = "bunker_vpn"
    }

    private var commandServer: CommandServer? = null
    private var tunDescriptor: ParcelFileDescriptor? = null
    @Volatile private var started = false
    @Volatile private var stopping = false
    @Volatile private var setupFailure: String? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        try {
            val setup = SetupOptions().apply {
                basePath = filesDir.absolutePath
                workingPath = (getExternalFilesDir(null) ?: filesDir).absolutePath
                tempPath = cacheDir.absolutePath
                debug = false
                logMaxLines = 1000
                appVersion = "12"
                appMarketingVersion = "1.6.0"
            }
            Libbox.setup(setup)
            Libbox.setLocale(java.util.Locale.getDefault().toLanguageTag())
        } catch (e: Exception) {
            setupFailure = e.message ?: e.javaClass.simpleName
            Log.e("BunkerVPN", "libbox setup failed", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel("Отключено")
            return START_NOT_STICKY
        }
        stopping = false
        val config = intent?.getStringExtra(EXTRA_CONFIG)
        if (config.isNullOrBlank()) {
            broadcast(false, "Нет конфигурации выбранного профиля")
            stopSelf()
            return START_NOT_STICKY
        }
        // Promote immediately; Android 14+ enforces a short foreground-service deadline.
        startForeground(NOTIFICATION_ID, notification("Запуск Бункера Кота…"))
        val setupError = setupFailure
        if (setupError != null) {
            broadcast(false, "Ошибка инициализации sing-box: $setupError")
            stopTunnel("Ошибка инициализации sing-box")
            return START_NOT_STICKY
        }
        if (prepare(this) != null) {
            broadcast(false, "Android не выдал разрешение VPN")
            stopTunnel("Нет разрешения VPN")
            return START_NOT_STICKY
        }
        Thread {
            try {
                // Do not publish connected state until libbox has accepted the full configuration.
                val server = CommandServer(this, this)
                commandServer = server
                server.start()
                server.startOrReloadService(config, OverrideOptions())
                if (stopping) return@Thread
                started = true
                broadcast(true, "Туннель sing-box запущен")
                val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(NOTIFICATION_ID, notification("VPN активен"))
            } catch (e: Exception) {
                Log.e("BunkerVPN", "start failed", e)
                val detail = e.message ?: e.javaClass.simpleName
                broadcast(false, "Не удалось запустить VPN: $detail")
                stopTunnel("Ошибка запуска: $detail")
            }
        }.start()
        return START_NOT_STICKY
    }

    override fun onRevoke() { stopTunnel("Разрешение VPN отозвано"); super.onRevoke() }
    override fun onDestroy() { stopTunnel("Отключено"); super.onDestroy() }

    @Synchronized private fun stopTunnel(message: String) {
        if (stopping) return
        stopping = true
        started = false
        try { tunDescriptor?.close() } catch (e: Exception) { Log.w("BunkerVPN", "tun close failed", e) }
        tunDescriptor = null
        val server = commandServer
        commandServer = null
        // closeService may invoke serviceStop(); the stopping guard prevents recursive teardown.
        try { server?.closeService() } catch (e: Exception) { Log.w("BunkerVPN", "closeService failed", e) }
        try { server?.close() } catch (e: Exception) { Log.w("BunkerVPN", "command server close failed", e) }
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        broadcast(false, message)
        stopSelf()
    }

    private fun broadcast(connected: Boolean, message: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName)
            .putExtra(EXTRA_CONNECTED, connected).putExtra(EXTRA_MESSAGE, message))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Бункер Кота VPN", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val stop = PendingIntent.getService(this, 1, Intent(this, BunkerVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Бункер Кота").setContentText(message).setContentIntent(open)
                .addAction(Notification.Action.Builder(null, "Отключить", stop).build()).setOngoing(started).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Бункер Кота")
                .setContentText(message).setContentIntent(open).setOngoing(started).build()
        }
    }

    // sing-box PlatformInterface callbacks
    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true
    override fun autoDetectInterfaceControl(fd: Int) { if (!protect(fd)) Log.w("BunkerVPN", "protect(fd) failed") }
    override fun useProcFS(): Boolean = false
    override fun openTun(options: TunOptions): Int {
        if (prepare(this) != null) throw IllegalStateException("VPN-разрешение не получено")
        val safeMtu = if (options.mtu in 1280..1500) options.mtu else 1400
        val builder = Builder().setSession("Бункер Кота").setMtu(safeMtu)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        val v4 = options.inet4Address
        while (v4.hasNext()) { val p = v4.next(); builder.addAddress(p.address(), p.prefix()) }
        val v6 = options.inet6Address
        while (v6.hasNext()) { val p = v6.next(); builder.addAddress(p.address(), p.prefix()) }
        if (options.autoRoute) {
            val dnsMode = options.dnsMode?.value ?: ""
            if (dnsMode != Libbox.DNSModeDisabled) {
                val dns = options.dnsServerAddress
                while (dns.hasNext()) builder.addDnsServer(dns.next())
            }
            val r4 = if (Build.VERSION.SDK_INT >= 33) options.inet4RouteAddress else options.inet4RouteRange
            while (r4.hasNext()) { val p = r4.next(); builder.addRoute(p.address(), p.prefix()) }
            val r6 = if (Build.VERSION.SDK_INT >= 33) options.inet6RouteAddress else options.inet6RouteRange
            while (r6.hasNext()) { val p = r6.next(); builder.addRoute(p.address(), p.prefix()) }
            if (Build.VERSION.SDK_INT >= 33) {
                val x4 = options.inet4RouteExcludeAddress
                while (x4.hasNext()) { val p = x4.next(); builder.excludeRoute(android.net.IpPrefix(java.net.InetAddress.getByName(p.address()), p.prefix())) }
                val x6 = options.inet6RouteExcludeAddress
                while (x6.hasNext()) { val p = x6.next(); builder.excludeRoute(android.net.IpPrefix(java.net.InetAddress.getByName(p.address()), p.prefix())) }
            }
            val include = options.includePackage
            while (include.hasNext()) builder.addAllowedApplication(include.next())
            val exclude = options.excludePackage
            while (exclude.hasNext()) builder.addDisallowedApplication(exclude.next())
        }
        val pfd = builder.establish() ?: throw IllegalStateException("Android не создал VPN-интерфейс")
        tunDescriptor = pfd
        return pfd.fd
    }
    override fun localDNSTransport(): LocalDNSTransport? = null
    override fun findConnectionOwner(ipProtocol: Int, sourceAddress: String, sourcePort: Int, destinationAddress: String, destinationPort: Int): ConnectionOwner {
        throw UnsupportedOperationException("Connection owner lookup is not enabled")
    }
    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) { }
    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) { }
    override fun getInterfaces(): NetworkInterfaceIterator {
        val list = ArrayList<io.nekohasekai.libbox.NetworkInterface>()
        try {
            val all = JavaNetworkInterface.getNetworkInterfaces()
            while (all.hasMoreElements()) {
                val item = all.nextElement()
                if (!item.isUp || item.isLoopback) continue
                val ni = io.nekohasekai.libbox.NetworkInterface()
                ni.name = item.name
                ni.index = item.index
                ni.mtu = try { item.mtu } catch (_: Exception) { 1500 }
                ni.addresses = Strings(item.interfaceAddresses.mapNotNull { a -> a.address?.hostAddress?.let { "$it/${a.networkPrefixLength}" } })
                ni.dnsServer = Strings(emptyList())
                ni.gateway = Strings(emptyList())
                ni.flags = 0
                ni.type = Libbox.InterfaceTypeOther
                ni.metered = false
                list.add(ni)
            }
        } catch (e: Exception) { Log.w("BunkerVPN", "interfaces unavailable", e) }
        return InterfaceList(list.iterator())
    }
    override fun underNetworkExtension(): Boolean = false
    override fun includeAllNetworks(): Boolean = false
    override fun readWIFIState(): WIFIState? = null
    override fun clearDNSCache() { }
    override fun sendNotification(notification: io.nekohasekai.libbox.Notification) { Log.i("sing-box", notification.body ?: "") }
    override fun cancelNotification(identifier: String, typeID: Int) { }
    override fun startNeighborMonitor(listener: NeighborUpdateListener?) { }
    override fun closeNeighborMonitor(listener: NeighborUpdateListener?) { }
    override fun registerMyInterface(name: String?) { }
    override fun usePlatformShell(): Boolean = false
    override fun checkPlatformShell() { throw UnsupportedOperationException("Shell is not available") }
    override fun openShellSession(user: PlatformUser?, command: String?, environ: StringIterator?, term: String?, rows: Int, cols: Int): ShellSession {
        throw UnsupportedOperationException("Shell is not available")
    }
    override fun lookupUser(username: String?): PlatformUser { throw UnsupportedOperationException("User lookup is not available") }
    override fun lookupSFTPServer(): String { throw UnsupportedOperationException("SFTP is not available") }
    override fun readSystemSSHHostKey(): String { throw UnsupportedOperationException("SSH is not available") }
    override fun tailscaleHostname(): String = "bunker-kot"
    override fun usePlatformBridge(): Boolean = false
    override fun createBridge(options: BridgeOptions?): BridgeSession { throw UnsupportedOperationException("Bridge is not available") }

    // sing-box CommandServerHandler callbacks
    override fun serviceStop() {
        // sing-box may call this from inside closeService(); never recurse into closeService again.
        if (stopping) return
        stopping = true
        started = false
        try { tunDescriptor?.close() } catch (_: Exception) { }
        tunDescriptor = null
        // Do not close CommandServer from inside its own callback; Android teardown closes it once.
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        broadcast(false, "sing-box остановил туннель")
        stopSelf()
    }
    override fun serviceReload() { }
    override fun getSystemProxyStatus(): SystemProxyStatus = SystemProxyStatus().apply { available = false; enabled = false }
    override fun setSystemProxyEnabled(enabled: Boolean) { }
    override fun triggerNativeCrash() { throw UnsupportedOperationException("Disabled") }
    override fun writeDebugMessage(message: String?) { Log.d("sing-box", message ?: "") }
    override fun connectSSHAgent(): Int = -1

    private class Strings(values: List<String>) : StringIterator {
        private val items = values
        private var index = 0
        override fun len(): Int = items.size
        override fun hasNext(): Boolean = index < items.size
        override fun next(): String = items[index++]
    }
    private class InterfaceList(private val iterator: Iterator<io.nekohasekai.libbox.NetworkInterface>) : NetworkInterfaceIterator {
        override fun hasNext(): Boolean = iterator.hasNext()
        override fun next(): io.nekohasekai.libbox.NetworkInterface = iterator.next()
    }
}
