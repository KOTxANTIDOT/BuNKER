package ru.bunkerkot.app;

import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;

public final class VlessConfig {
    private VlessConfig() { }

    public static String fromUri(String raw) throws Exception {
        Uri uri = Uri.parse(raw.trim());
        if (!"vless".equalsIgnoreCase(uri.getScheme())) throw new IllegalArgumentException("Поддерживаются VLESS-профили");
        String uuid = uri.getUserInfo();
        String host = uri.getHost();
        int port = uri.getPort();
        if (uuid == null || uuid.isEmpty() || host == null || host.isEmpty() || port < 1 || port > 65535)
            throw new IllegalArgumentException("В ссылке не хватает UUID, сервера или порта");

        String security = q(uri, "security", "none").toLowerCase();
        JSONObject outbound = new JSONObject();
        outbound.put("type", "vless");
        outbound.put("tag", "proxy");
        outbound.put("server", host);
        outbound.put("server_port", port);
        outbound.put("uuid", uuid);
        String flow = q(uri, "flow", "");
        if (!flow.isEmpty()) outbound.put("flow", flow);
        outbound.put("packet_encoding", "xudp");

        if (security.equals("reality") || security.equals("tls")) {
            JSONObject tls = new JSONObject();
            tls.put("enabled", true);
            tls.put("server_name", q(uri, "sni", host));
            tls.put("insecure", false);
            String fp = q(uri, "fp", "");
            if (!fp.isEmpty()) tls.put("utls", new JSONObject().put("enabled", true).put("fingerprint", fp));
            if (security.equals("reality")) {
                String pbk = q(uri, "pbk", q(uri, "publicKey", ""));
                if (pbk.isEmpty()) throw new IllegalArgumentException("Для Reality-ссылки отсутствует pbk/publicKey");
                tls.put("reality", new JSONObject().put("enabled", true).put("public_key", pbk).put("short_id", q(uri, "sid", q(uri, "shortId", ""))));
            }
            outbound.put("tls", tls);
        }

        String type = q(uri, "type", "tcp").toLowerCase();
        if (type.equals("ws")) {
            JSONObject transport = new JSONObject().put("type", "ws");
            String path = q(uri, "path", "");
            if (!path.isEmpty()) transport.put("path", path);
            String hostHeader = q(uri, "host", "");
            if (!hostHeader.isEmpty()) transport.put("headers", new JSONObject().put("Host", hostHeader));
            outbound.put("transport", transport);
        } else if (type.equals("grpc")) {
            outbound.put("transport", new JSONObject().put("type", "grpc").put("service_name", q(uri, "serviceName", q(uri, "service_name", ""))));
        } else if (!type.equals("tcp") && !type.equals("raw")) {
            throw new IllegalArgumentException("Транспорт " + type + " пока не поддержан в этом билде");
        }

        JSONArray dnsServers = new JSONArray().put(new JSONObject().put("tag", "dns-remote").put("address", "1.1.1.1").put("detour", "proxy"));
        JSONArray outbounds = new JSONArray()
            .put(outbound)
            .put(new JSONObject().put("type", "direct").put("tag", "direct"))
            .put(new JSONObject().put("type", "dns").put("tag", "dns-out"));
        JSONObject route = new JSONObject()
            .put("auto_detect_interface", true)
            .put("final", "proxy")
            .put("rules", new JSONArray().put(new JSONObject().put("protocol", "dns").put("outbound", "dns-out")));
        JSONObject config = new JSONObject()
            .put("log", new JSONObject().put("level", "info"))
            .put("dns", new JSONObject().put("servers", dnsServers).put("final", "dns-remote"))
            .put("inbounds", new JSONArray().put(new JSONObject()
                .put("type", "tun").put("tag", "tun-in")
                .put("inet4_address", new JSONArray().put("172.19.0.1/30"))
                .put("inet6_address", new JSONArray().put("fdfe:dcba:9876::1/126"))
                .put("mtu", 1400).put("auto_route", true).put("strict_route", false)
                .put("stack", "system")))
            .put("outbounds", outbounds)
            .put("route", route);
        return config.toString();
    }

    private static String q(Uri uri, String key, String fallback) {
        String value = uri.getQueryParameter(key);
        return value == null ? fallback : value;
    }
}
