# Бункер Кота v1.4.1

## Изменения
- Добавлено Android VPN Service на базе sing-box/libbox 1.14.3.
- VLESS-ссылки конвертируются в конфигурацию sing-box для TCP, TLS и Reality; поддержан WebSocket/gRPC транспорт.
- Запуск/остановка VPN через разрешение Android, foreground notification и реальные статусы сервиса.
- Убраны видимые кнопки ручного импорта и вставки; добавлен блок «Подписки Бункера».
- Файл `app/src/main/assets/subscriptions.json` — место для списка ваших встроенных подписок; сейчас пустой, потому что адреса подписок в запросе не предоставлены.
- Иконка и главный экран с котом/сердцем сохранены.

## Важно
Это первая интеграция движка, но её необходимо собрать через GitHub Actions и проверить на устройстве с реальным сервером. Успешная сборка не гарантирует успешный коннект к каждому серверу: VLESS-ссылка должна содержать нужные Reality/TLS параметры. Не включайте зелёный статус вручную — UI получает его от VPN-сервиса.

Ядро libbox распространяется по GPL-3.0; перед публичным распространением приложения нужно соблюсти лицензионные условия, включая публикацию соответствующего исходного кода и лицензий.

## Сборка
Из корня проекта: `gradle :app:assembleDebug`


Minimum Android version: Android 7.0 (API 24), required by the libbox dependency.


## v1.4.2 build fix
- Fixed IpPrefix address construction for excluded routes.
- Removed the unsupported dnsSearchDomain property and auto-redirect callbacks that are not exposed by the configured libbox AAR API.
- minSdk remains 24.
