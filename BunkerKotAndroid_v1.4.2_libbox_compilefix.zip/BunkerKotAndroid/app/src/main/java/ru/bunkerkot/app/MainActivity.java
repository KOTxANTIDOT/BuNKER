package ru.bunkerkot.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.VpnService;
import android.content.BroadcastReceiver;
import android.content.IntentFilter;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(10, 10, 10);
    private final int PANEL = Color.rgb(22, 22, 22);
    private final int ORANGE = Color.rgb(255, 145, 35);
    private final int WHITE = Color.rgb(245, 245, 245);
    private final int MUTED = Color.rgb(150, 150, 150);
    private final int GREEN = Color.rgb(78, 190, 112);

    private SharedPreferences prefs;
    private final List<Profile> profiles = new ArrayList<>();
    private int selected = -1;
    private TextView status, statusSub, cfgName, profileCount, pingValue;
    private LinearLayout profileList;
    private Button connectButton;
    private ImageView heroArtwork;
    private boolean vpnConnected = false;
    private static final int VPN_PERMISSION_REQUEST = 2002;
    private String pendingVpnConfig;
    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!BunkerVpnService.ACTION_STATE.equals(intent.getAction())) return;
            vpnConnected = intent.getBooleanExtra(BunkerVpnService.EXTRA_CONNECTED, false);
            String message = intent.getStringExtra(BunkerVpnService.EXTRA_MESSAGE);
            updateVpnUi(message);
        }
    };

    private static class Profile {
        String name;
        String uri;
        Profile(String name, String uri) { this.name = name; this.uri = uri; }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("bunker_profiles", MODE_PRIVATE);
        loadProfiles();
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(24));
        scroll.addView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher_round);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        TextView title = text("БУНКЕР КОТА", 22, WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titles.addView(title);
        titles.addView(text("VPN  •  Proxy  •  Telegram", 12, MUTED));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        TextView menu = text("⋮", 30, MUTED);
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu, new LinearLayout.LayoutParams(dp(32), dp(46)));
        root.addView(header);

        space(root, 12);
        LinearLayout card = panel();
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.addView(text("●", 12, ORANGE), wrap());
        status = text("НЕ ПОДКЛЮЧЕНО", 17, ORANGE);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        status.setPadding(dp(8), 0, 0, 0);
        statusRow.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("READY", 10, MUTED);
        badge.setGravity(Gravity.CENTER);
        badge.setBackgroundResource(R.drawable.bg_badge);
        statusRow.addView(badge, new LinearLayout.LayoutParams(dp(60), dp(26)));
        card.addView(statusRow);
        space(card, 6);
        statusSub = text("Выбери профиль. Настоящий туннель будет отмечен только после запуска движка.", 12, MUTED);
        card.addView(statusSub);
        root.addView(card);

        space(root, 8);
        FrameLayout hero = new FrameLayout(this);
        hero.setClipToPadding(false);
        heroArtwork = new ImageView(this);
        heroArtwork.setImageResource(R.drawable.cat_heart_hero);
        heroArtwork.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(heroArtwork, new FrameLayout.LayoutParams(-1, -1));
        // Text sits on the heart held by the cat. The visual state is changed only by real VPN state.
        connectButton = new Button(this);
        connectButton.setText("В БУНКЕР");
        connectButton.setTextSize(13);
        connectButton.setTextColor(Color.BLACK);
        connectButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        connectButton.setAllCaps(false);
        connectButton.setBackgroundColor(Color.TRANSPARENT);
        connectButton.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams heartButtonParams = new FrameLayout.LayoutParams(dp(206), dp(58), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        heartButtonParams.topMargin = dp(248);
        hero.addView(connectButton, heartButtonParams);
        root.addView(hero, new LinearLayout.LayoutParams(-1, dp(390)));
        connectButton.setOnClickListener(v -> toggleVpn());

        LinearLayout subscriptionCard = panel();
        subscriptionCard.setPadding(dp(16), dp(12), dp(16), dp(12));
        subscriptionCard.addView(label("ПОДПИСКИ БУНКЕРА"));
        space(subscriptionCard, 5);
        subscriptionCard.addView(text("Встроенные подписки подключим сюда. Сейчас можно использовать уже сохранённые профили.", 12, MUTED));
        space(subscriptionCard, 8);
        Button refreshSubs = secondaryButton("ОБНОВИТЬ ПОДПИСКИ");
        refreshSubs.setOnClickListener(v -> new AlertDialog.Builder(this)
            .setTitle("Подписки Бункера")
            .setMessage("Адреса ваших подписок ещё не внесены в проект. Пришли ссылки на подписки — встрою их сюда, без кнопок ручного импорта.")
            .setPositiveButton("Понятно", null).show());
        subscriptionCard.addView(refreshSubs, new LinearLayout.LayoutParams(-1, dp(44)));
        root.addView(subscriptionCard);

        space(root, 14);
        LinearLayout cfg = panel();
        cfg.setPadding(dp(16), dp(13), dp(16), dp(13));
        cfg.addView(label("ТЕКУЩИЙ ПРОФИЛЬ"));
        space(cfg, 6);
        cfgName = text("Профиль не выбран", 16, WHITE);
        cfgName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        cfg.addView(cfgName);
        space(cfg, 4);
        cfg.addView(text("VLESS  •  Reality / TLS  •  TCP / другие транспорты", 11, MUTED));
        root.addView(cfg);

        space(root, 10);
        LinearLayout stats = new LinearLayout(this);
        LinearLayout countCard = statCard("0", "ПРОФИЛЕЙ");
        profileCount = (TextView) countCard.getChildAt(0);
        stats.addView(countCard, new LinearLayout.LayoutParams(0, dp(72), 1));
        LinearLayout pingCard = statCard("—", "PING");
        pingValue = (TextView) pingCard.getChildAt(0);
        LinearLayout.LayoutParams pingParams = new LinearLayout.LayoutParams(0, dp(72), 1);
        pingParams.leftMargin = dp(8);
        stats.addView(pingCard, pingParams);
        root.addView(stats);

        space(root, 14);
        TextView profilesTitle = text("СОХРАНЁННЫЕ ПРОФИЛИ", 12, ORANGE);
        profilesTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(profilesTitle);
        space(root, 7);
        profileList = new LinearLayout(this);
        profileList.setOrientation(LinearLayout.VERTICAL);
        root.addView(profileList);

        space(root, 16);
        TextView footer = text("БУНКЕР КОТА  •  v1.4", 11, MUTED);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);
        setContentView(scroll);
        renderProfiles();
        updateVpnUi(vpnConnected ? "VPN активен" : "Выбери профиль для подключения");
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(vpnReceiver, new IntentFilter(BunkerVpnService.ACTION_STATE), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(vpnReceiver, new IntentFilter(BunkerVpnService.ACTION_STATE));
    }


    @Override protected void onDestroy() {
        try { unregisterReceiver(vpnReceiver); } catch (Exception ignored) { }
        super.onDestroy();
    }

    private void toggleVpn() {
        if (vpnConnected) {
            startService(new Intent(this, BunkerVpnService.class).setAction(BunkerVpnService.ACTION_STOP));
            return;
        }
        if (selected < 0 || selected >= profiles.size()) {
            toast("Сначала выбери профиль из списка");
            return;
        }
        try {
            pendingVpnConfig = VlessConfig.fromUri(profiles.get(selected).uri);
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
            else startVpnService(pendingVpnConfig);
        } catch (Exception e) {
            new AlertDialog.Builder(this).setTitle("Не удалось подготовить профиль")
                .setMessage(e.getMessage() == null ? "Проверь VLESS-ссылку" : e.getMessage())
                .setPositiveButton("ОК", null).show();
        }
    }

    private void startVpnService(String config) {
        Intent intent = new Intent(this, BunkerVpnService.class)
            .setAction(BunkerVpnService.ACTION_START)
            .putExtra(BunkerVpnService.EXTRA_CONFIG, config);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        status.setText("ПОДКЛЮЧАЕМСЯ");
        status.setTextColor(ORANGE);
        statusSub.setText("Запускаем sing-box и создаём VPN-туннель…");
        connectButton.setText("ЗАПУСК…");
    }

    private void updateVpnUi(String message) {
        if (status == null || connectButton == null) return;
        if (vpnConnected) {
            status.setText("ПОДКЛЮЧЕНО");
            status.setTextColor(GREEN);
            connectButton.setText("ОТКЛЮЧИТЬ");
            statusSub.setText(message == null ? "VPN-туннель запущен." : message);
            heroArtwork.setColorFilter(Color.argb(38, 255, 130, 20), android.graphics.PorterDuff.Mode.SRC_ATOP);
        } else {
            status.setText("НЕ ПОДКЛЮЧЕНО");
            status.setTextColor(ORANGE);
            connectButton.setText("В БУНКЕР");
            statusSub.setText(message == null ? "Выбери профиль и нажми на сердце." : message);
            heroArtwork.clearColorFilter();
        }
    }

    private void openFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("*/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 1001);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK && pendingVpnConfig != null) startVpnService(pendingVpnConfig);
            else toast("Для подключения нужно разрешение VPN от Android");
            return;
        }
        if (requestCode != 1001 || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(getContentResolver().openInputStream(uri), StandardCharsets.UTF_8))) {
            StringBuilder all = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) all.append(line.trim()).append('\n');
            int added = importText(all.toString());
            toast(added > 0 ? "Импортировано профилей: " + added : "В файле не найдено VLESS-ссылок");
        } catch (Exception e) {
            toast("Не удалось прочитать файл: " + e.getMessage());
        }
    }

    private void showPasteDialog() {
        EditText input = new EditText(this);
        input.setTextColor(WHITE);
        input.setHintTextColor(MUTED);
        input.setHint("vless://…\nМожно вставить несколько ссылок");
        input.setGravity(Gravity.TOP | Gravity.START);
        input.setMinLines(4);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setPadding(dp(12), dp(12), dp(12), dp(12));
        new AlertDialog.Builder(this)
            .setTitle("Импорт VLESS")
            .setView(input)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить", (dialog, which) -> {
                int added = importText(input.getText().toString());
                toast(added > 0 ? "Сохранено профилей: " + added : "Не вижу корректных vless:// ссылок");
            }).show();
    }

    private int importText(String text) {
        int added = 0;
        String[] lines = text.split("[\\r\\n\\s]+");
        for (String raw : lines) {
            String key = raw.trim();
            if (!key.startsWith("vless://") || !key.contains("@") || !key.contains("?")) continue;
            boolean exists = false;
            for (Profile profile : profiles) if (profile.uri.equals(key)) { exists = true; break; }
            if (exists) continue;
            String name = extractName(key);
            profiles.add(new Profile(name, key));
            selected = profiles.size() - 1;
            added++;
        }
        if (added > 0) {
            saveProfiles();
            renderProfiles();
            statusSub.setText("Профиль сохранён. Для туннеля ещё требуется VPN-движок.");
        }
        return added;
    }

    private String extractName(String uri) {
        try {
            int hash = uri.indexOf('#');
            if (hash >= 0 && hash < uri.length() - 1) {
                String name = URLDecoder.decode(uri.substring(hash + 1), "UTF-8").trim();
                if (!name.isEmpty()) return name;
            }
            int at = uri.indexOf('@');
            int colon = uri.indexOf(':', at);
            String host = colon > at ? uri.substring(at + 1, colon) : uri.substring(at + 1);
            return host.isEmpty() ? "VLESS профиль" : host;
        } catch (Exception e) { return "VLESS профиль"; }
    }

    private void loadProfiles() {
        try {
            JSONArray array = new JSONArray(prefs.getString("profiles", "[]"));
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                String storedName = o.getString("name");
                String storedUri = o.getString("uri");
                if (storedName == null || storedName.trim().isEmpty() || storedName.equalsIgnoreCase("BUNKER") || storedName.equalsIgnoreCase("VLESS профиль")) storedName = extractName(storedUri);
                profiles.add(new Profile(storedName, storedUri));
            }
            selected = prefs.getInt("selected", profiles.isEmpty() ? -1 : 0);
            if (selected >= profiles.size()) selected = profiles.isEmpty() ? -1 : 0;
        } catch (Exception ignored) { profiles.clear(); selected = -1; }
    }

    private void saveProfiles() {
        JSONArray array = new JSONArray();
        for (Profile profile : profiles) {
            JSONObject o = new JSONObject();
            try { o.put("name", profile.name); o.put("uri", profile.uri); array.put(o); } catch (Exception ignored) { }
        }
        prefs.edit().putString("profiles", array.toString()).putInt("selected", selected).apply();
    }

    private void renderProfiles() {
        if (profileList == null) return;
        profileList.removeAllViews();
        profileCount.setText(String.valueOf(profiles.size()));
        if (selected >= 0 && selected < profiles.size()) {
            cfgName.setText(profiles.get(selected).name);
        } else cfgName.setText("Конфигурация не выбрана");
        if (profiles.isEmpty()) {
            TextView empty = text("Пока пусто. Вставь VLESS-ссылку или импортируй TXT.", 13, MUTED);
            empty.setPadding(dp(12), dp(14), dp(12), dp(14));
            profileList.addView(empty);
            return;
        }
        for (int i = 0; i < profiles.size(); i++) {
            final int index = i;
            Profile profile = profiles.get(i);
            LinearLayout row = panel();
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(10), dp(8), dp(10));
            row.setBackgroundResource(i == selected ? R.drawable.bg_secondary : R.drawable.bg_panel);
            TextView info = text((i == selected ? "●  " : "○  ") + profile.name, 14, i == selected ? ORANGE : WHITE);
            info.setMaxLines(2);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            Button choose = new Button(this);
            choose.setText("Выбрать");
            choose.setTextSize(11);
            choose.setTextColor(WHITE);
            choose.setAllCaps(false);
            choose.setBackgroundColor(Color.TRANSPARENT);
            choose.setOnClickListener(v -> { selected = index; saveProfiles(); renderProfiles(); });
            row.addView(choose, wrap());
            Button remove = new Button(this);
            remove.setText("×");
            remove.setTextSize(22);
            remove.setTextColor(MUTED);
            remove.setAllCaps(false);
            remove.setBackgroundColor(Color.TRANSPARENT);
            remove.setOnClickListener(v -> new AlertDialog.Builder(this).setTitle("Удалить профиль?").setMessage(profile.name).setNegativeButton("Отмена", null).setPositiveButton("Удалить", (d, w) -> { profiles.remove(index); if (profiles.isEmpty()) selected = -1; else if (selected >= profiles.size()) selected = profiles.size() - 1; else if (index < selected) selected--; saveProfiles(); renderProfiles(); }).show());
            row.addView(remove, new LinearLayout.LayoutParams(dp(40), dp(44)));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(8);
            profileList.addView(row, rp);
        }
    }

    private void showMenu() {
        String[] items = {"Удалить все профили", "О приложении"};
        new AlertDialog.Builder(this).setTitle("Бункер Кота").setItems(items, (d, which) -> {
            if (which == 0) new AlertDialog.Builder(this).setMessage("Удалить все сохранённые профили?").setNegativeButton("Отмена", null).setPositiveButton("Удалить", (dd, ww) -> { profiles.clear(); selected = -1; saveProfiles(); renderProfiles(); toast("Профили удалены"); }).show();
            else new AlertDialog.Builder(this).setTitle("Бункер Кота v1.4 • sing-box 1.14.3").setMessage("Встроенное ядро sing-box/libbox 1.14.3. Подключение работает с поддерживаемыми VLESS TCP, TLS и Reality профилями; фактический результат зависит от параметров сервера.").setPositiveButton("ОК", null).show();
        }).show();
    }

    private LinearLayout panel() { LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setBackgroundResource(R.drawable.bg_panel); return p; }
    private LinearLayout statCard(String value, String caption) { LinearLayout p = panel(); p.setPadding(dp(16), dp(10), dp(16), dp(10)); TextView v = text(value, 23, WHITE); v.setTypeface(Typeface.DEFAULT, Typeface.BOLD); p.addView(v); p.addView(text(caption, 10, MUTED)); return p; }
    private TextView label(String s) { return text(s, 10, ORANGE); }
    private Button primaryButton(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(14); b.setTextColor(Color.BLACK); b.setTypeface(Typeface.DEFAULT, Typeface.BOLD); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackgroundResource(R.drawable.bg_button); b.setPadding(dp(12), 0, dp(12), 0); return b; }
    private Button secondaryButton(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(13); b.setTextColor(WHITE); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackgroundResource(R.drawable.bg_secondary); b.setPadding(dp(8), 0, dp(8), 0); return b; }
    private TextView text(String s, float size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t; }
    private LinearLayout.LayoutParams wrap() { return new LinearLayout.LayoutParams(-2, -2); }
    private void space(LinearLayout p, int h) { View v = new View(this); p.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
