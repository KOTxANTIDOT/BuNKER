package ru.bunkerkot.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(8, 8, 8);
    private static final int PANEL = Color.rgb(21, 21, 21);
    private static final int ORANGE = Color.rgb(255, 145, 35);
    private static final int WHITE = Color.rgb(245, 243, 240);
    private static final int MUTED = Color.rgb(154, 151, 148);
    private static final int GREEN = Color.rgb(88, 210, 126);
    private static final int RED = Color.rgb(235, 95, 85);
    private static final int VPN_PERMISSION_REQUEST = 2002;
    private static final int MAX_VISIBLE_NODES = 60;
    private static final String PREFS = "bunker_local_v3";
    private static final String KEY_WHITE_SOURCES = "white_sources";
    private static final String KEY_BLACK_SOURCES = "black_sources";
    private static final String KEY_WHITE_CACHE = "white_cache";
    private static final String KEY_BLACK_CACHE = "black_cache";

    private final List<Profile> profiles = new ArrayList<>();
    private final List<Source> sources = new ArrayList<>();
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
    private final AtomicBoolean loading = new AtomicBoolean(false);
    private final AtomicBoolean testingUrls = new AtomicBoolean(false);
    private volatile boolean precheckRunning = false;
    private volatile boolean precheckWaiting = false;
    private volatile boolean precheckConnected = false;
    private volatile String precheckMessage = "";

    private int selected = -1;
    private boolean blackListSelected = false;
    private boolean vpnConnected = false;
    private boolean suppressSearch = false;
    private String pendingVpnConfig;
    private String searchText = "";

    private TextView status, statusSub, cfgName, nodeCount, sourceCount, connectButton, emptyHint;
    private TextView urlTestSummary;
    private LinearLayout nodeList, sourceList;
    private EditText searchBox;
    private Button whiteButton, blackButton, addSourceButton, refreshButton, testUrlsButton;
    private ImageView heroArtwork;

    private static class Profile {
        final String name;
        final String uri;
        Profile(String name, String uri) { this.name = name; this.uri = uri; }
    }

    private static class Source {
        String name;
        String url;
        String testText = "не проверен";
        int testColor = MUTED;
        Source(String name, String url) { this.name = name; this.url = url; }
    }

    private static class HttpResult {
        int code = -1;
        long ms = -1;
        String body = "";
        String error = null;
    }

    private final BroadcastReceiver vpnReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!BunkerVpnService.ACTION_STATE.equals(intent.getAction())) return;
            vpnConnected = intent.getBooleanExtra(BunkerVpnService.EXTRA_CONNECTED, false);
            precheckMessage = intent.getStringExtra(BunkerVpnService.EXTRA_MESSAGE);
            if (precheckWaiting) {
                precheckConnected = vpnConnected;
                precheckWaiting = false;
            }
            updateVpnUi(precheckMessage);
        }
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(BG);
        window.setNavigationBarColor(BG);
        window.getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(10), dp(16), dp(22));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -1));
        applySystemInsets(root);

        buildHeader(root);
        buildStatus(root);
        buildHero(root);
        buildSubscriptions(root);
        buildServers(root);
        buildFooter(root);

        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 33) registerReceiver(vpnReceiver, new IntentFilter(BunkerVpnService.ACTION_STATE), Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(vpnReceiver, new IntentFilter(BunkerVpnService.ACTION_STATE));

        loadLocalData();
        updateModeButtons();
        renderSources();
        renderNodes();
        updateVpnUi("Готов к работе. Добавь подписку или импортируй VLESS-ссылку.");

        scheduler.scheduleWithFixedDelay(() -> runOnUiThread(() -> {
            if (!isFinishing() && !sources.isEmpty()) refreshSubscriptions(false, false);
        }), 30, 30, TimeUnit.MINUTES);
        scheduler.scheduleWithFixedDelay(() -> runOnUiThread(() -> {
            if (!isFinishing() && vpnConnected) testActiveServerUrl();
        }), 5, 5, TimeUnit.MINUTES);
    }

    private void applySystemInsets(LinearLayout root) {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            if (Build.VERSION.SDK_INT >= 23) {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
            }
            root.setPadding(dp(16), top + dp(10), dp(16), bottom + dp(22));
            return insets;
        });
        root.post(() -> root.requestApplyInsets());
    }

    private void buildHeader(LinearLayout root) {
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_launcher_round);
        logo.setScaleType(ImageView.ScaleType.CENTER_CROP);
        header.addView(logo, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(11), 0, 0, 0);
        TextView title = text("Бункер Кота", 22, WHITE);
        title.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        title.setLetterSpacing(-0.02f);
        titles.addView(title);
        TextView subtitle = text("VPN  ·  PROXY  ·  TELEGRAM", 10, MUTED);
        subtitle.setLetterSpacing(0.06f);
        titles.addView(subtitle);
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        TextView menu = text("⋮", 28, MUTED);
        menu.setGravity(Gravity.CENTER);
        menu.setOnClickListener(v -> showMenu());
        header.addView(menu, new LinearLayout.LayoutParams(dp(32), dp(44)));
        root.addView(header);
        space(root, 10);
    }

    private void buildStatus(LinearLayout root) {
        LinearLayout card = panel();
        card.setPadding(dp(16), dp(13), dp(16), dp(13));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(text("●", 12, ORANGE), wrap());
        status = text("НЕ ПОДКЛЮЧЕНО", 17, ORANGE);
        status.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        status.setPadding(dp(8), 0, 0, 0);
        row.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("SING-BOX", 9, MUTED);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(9), 0, dp(9), 0);
        badge.setBackgroundResource(R.drawable.bg_badge);
        row.addView(badge, new LinearLayout.LayoutParams(-2, dp(26)));
        card.addView(row);
        space(card, 6);
        statusSub = text("Готов к работе", 12, MUTED);
        statusSub.setMaxLines(2);
        statusSub.setEllipsize(TextUtils.TruncateAt.END);
        card.addView(statusSub);
        root.addView(card);
        space(root, 8);
    }

    private void buildHero(LinearLayout root) {
        FrameLayout hero = new FrameLayout(this);
        hero.setBackgroundColor(BG);
        heroArtwork = new ImageView(this);
        heroArtwork.setImageResource(R.drawable.cat_heart_hero);
        heroArtwork.setScaleType(ImageView.ScaleType.CENTER_CROP);
        hero.addView(heroArtwork, new FrameLayout.LayoutParams(-1, -1));

        connectButton = text("ПОДКЛЮЧИТЬ", 14, Color.rgb(34, 13, 3));
        connectButton.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        connectButton.setLetterSpacing(0.045f);
        connectButton.setGravity(Gravity.CENTER);
        connectButton.setClickable(true);
        connectButton.setFocusable(true);
        connectButton.setBackgroundColor(Color.TRANSPARENT);
        hero.addView(connectButton, new FrameLayout.LayoutParams(dp(196), dp(48), Gravity.CENTER));
        hero.addOnLayoutChangeListener((v, left, top, right, bottom, oldLeft, oldTop, oldRight, oldBottom) -> {
            int h = bottom - top;
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) connectButton.getLayoutParams();
            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
            lp.topMargin = (int) (h * 0.69f) - dp(24);
            connectButton.setLayoutParams(lp);
        });
        connectButton.setOnClickListener(v -> toggleVpn());
        root.addView(hero, new LinearLayout.LayoutParams(-1, dp(380)));
        space(root, 8);
    }

    private void buildSubscriptions(LinearLayout root) {
        LinearLayout card = panel();
        card.setPadding(dp(14), dp(13), dp(14), dp(13));
        TextView title = label("ПОДПИСКИ БУНКЕРА");
        title.setLetterSpacing(0.06f);
        card.addView(title);
        space(card, 9);

        LinearLayout switchRow = new LinearLayout(this);
        whiteButton = modeButton("БЕЛЫЙ СПИСОК");
        blackButton = modeButton("ЧЁРНЫЙ СПИСОК");
        switchRow.addView(whiteButton, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, dp(44), 1);
        bp.leftMargin = dp(8);
        switchRow.addView(blackButton, bp);
        card.addView(switchRow);
        whiteButton.setOnClickListener(v -> selectList(false));
        blackButton.setOnClickListener(v -> selectList(true));

        space(card, 8);
        LinearLayout actions = new LinearLayout(this);
        addSourceButton = secondaryButton("+ ДОБАВИТЬ");
        refreshButton = secondaryButton("ОБНОВИТЬ");
        testUrlsButton = secondaryButton("ПРОВЕРИТЬ СЕРВЕРЫ");
        actions.addView(addSourceButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0, dp(42), 1);
        ap.leftMargin = dp(6);
        actions.addView(refreshButton, ap);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, dp(42), 1);
        tp.leftMargin = dp(6);
        actions.addView(testUrlsButton, tp);
        card.addView(actions);
        addSourceButton.setOnClickListener(v -> showAddSourceDialog());
        refreshButton.setOnClickListener(v -> refreshSubscriptions(true, true));
        testUrlsButton.setOnClickListener(v -> {
            if (vpnConnected) testActiveServerUrl();
            else precheckAllServers();
        });

        space(card, 9);
        sourceCount = text("0 источников", 10, MUTED);
        card.addView(sourceCount);
        space(card, 5);
        sourceList = new LinearLayout(this);
        sourceList.setOrientation(LinearLayout.VERTICAL);
        card.addView(sourceList);
        space(card, 7);
        urlTestSummary = text("ПРОВЕРКА: t.me + YouTube + ChatGPT через каждый сервер", 10, MUTED);
        card.addView(urlTestSummary);
        root.addView(card);
        space(root, 11);
    }

    private void buildServers(LinearLayout root) {
        root.addView(label("ТЕКУЩИЙ СЕРВЕР"));
        space(root, 4);
        cfgName = text("Сервер не выбран", 16, WHITE);
        cfgName.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        root.addView(cfgName);
        space(root, 9);

        searchBox = new EditText(this);
        searchBox.setSingleLine(true);
        searchBox.setTextSize(14);
        searchBox.setTextColor(WHITE);
        searchBox.setHintTextColor(MUTED);
        searchBox.setHint("Поиск сервера");
        searchBox.setPadding(dp(14), 0, dp(14), 0);
        searchBox.setBackgroundResource(R.drawable.bg_secondary);
        root.addView(searchBox, new LinearLayout.LayoutParams(-1, dp(46)));
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (suppressSearch) return;
                searchText = s.toString().trim().toLowerCase(Locale.ROOT);
                renderNodes();
            }
            @Override public void afterTextChanged(Editable s) { }
        });
        space(root, 7);
        nodeCount = text("0 серверов", 10, MUTED);
        root.addView(nodeCount);
        nodeList = new LinearLayout(this);
        nodeList.setOrientation(LinearLayout.VERTICAL);
        root.addView(nodeList);
        emptyHint = text("", 12, MUTED);
        root.addView(emptyHint);
    }

    private void buildFooter(LinearLayout root) {
        space(root, 12);
        TextView footer = text("БУНКЕР КОТА  •  SING-BOX  •  ЛОКАЛЬНЫЕ СПИСКИ", 9, MUTED);
        footer.setGravity(Gravity.CENTER);
        footer.setLetterSpacing(0.06f);
        root.addView(footer);
    }

    private void loadLocalData() {
        loadSources(blackListSelected);
        restoreCachedProfiles();
    }

    private void selectList(boolean useBlack) {
        if (blackListSelected == useBlack) return;
        if (vpnConnected) startService(new Intent(this, BunkerVpnService.class).setAction(BunkerVpnService.ACTION_STOP));
        blackListSelected = useBlack;
        profiles.clear();
        selected = -1;
        searchText = "";
        suppressSearch = true;
        if (searchBox != null) searchBox.setText("");
        suppressSearch = false;
        loadSources(useBlack);
        restoreCachedProfiles();
        updateModeButtons();
        renderSources();
        renderNodes();
    }

    private void updateModeButtons() {
        if (whiteButton == null || blackButton == null) return;
        styleModeButton(whiteButton, !blackListSelected);
        styleModeButton(blackButton, blackListSelected);
        if (sourceCount != null) sourceCount.setText(sources.size() + (sources.size() == 1 ? " источник" : " источника"));
        if (nodeCount != null) nodeCount.setText(profiles.size() + (profiles.size() == 1 ? " сервер" : " серверов"));
    }

    private void styleModeButton(Button button, boolean active) {
        button.setTextColor(active ? Color.BLACK : WHITE);
        button.setBackgroundResource(active ? R.drawable.bg_button : R.drawable.bg_secondary);
        button.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
    }

    private Button modeButton(String title) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(10);
        b.setAllCaps(false);
        b.setPadding(dp(4), 0, dp(4), 0);
        b.setBackgroundResource(R.drawable.bg_secondary);
        return b;
    }

    private void showAddSourceDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(4), dp(20), 0);

        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setHint("Название (необязательно)");
        name.setTextColor(WHITE);
        name.setHintTextColor(MUTED);
        box.addView(name, new LinearLayout.LayoutParams(-1, dp(50)));

        EditText url = new EditText(this);
        url.setSingleLine(false);
        url.setMinLines(2);
        url.setMaxLines(4);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setHint("https://... или vless://...");
        url.setTextColor(WHITE);
        url.setHintTextColor(MUTED);
        box.addView(url, new LinearLayout.LayoutParams(-1, dp(74)));

        TextView mode = text("Добавится в: " + (blackListSelected ? "ЧЁРНЫЙ СПИСОК" : "БЕЛЫЙ СПИСОК"), 11, ORANGE);
        box.addView(mode);

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Добавить подписку")
            .setView(box)
            .setNegativeButton("ОТМЕНА", null)
            .setPositiveButton("ДОБАВИТЬ", null)
            .create();

        dialog.setOnShowListener(d -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String raw = url.getText().toString().trim();
            if (raw.isEmpty()) { url.setError("Вставь URL или VLESS-ссылку"); return; }
            String normalized = raw.replace("\\n", "\n").trim();
            String sourceName = name.getText().toString().trim();
            if (normalized.toLowerCase(Locale.ROOT).startsWith("vless://")) {
                addLocalVless(sourceName, normalized);
                dialog.dismiss();
                return;
            }
            try {
                Uri parsed = Uri.parse(normalized);
                if (!"https".equalsIgnoreCase(parsed.getScheme())) throw new IllegalArgumentException("Используй HTTPS URL подписки");
                if (parsed.getHost() == null) throw new IllegalArgumentException("Некорректный URL");
            } catch (Exception e) {
                url.setError(e.getMessage() == null ? "Некорректный URL" : e.getMessage());
                return;
            }
            String finalName = sourceName.isEmpty() ? hostName(normalized) : sourceName;
            for (Source s : sources) if (s.url.equals(normalized)) { url.setError("Такая подписка уже добавлена"); return; }
            sources.add(new Source(finalName, normalized));
            saveSources();
            renderSources();
            dialog.dismiss();
            refreshSubscriptions(true, true);
        }));
        dialog.show();
    }

    private void addLocalVless(String name, String uri) {
        try {
            Uri parsed = Uri.parse(uri);
            if (parsed.getHost() == null || parsed.getPort() < 1 || parsed.getUserInfo() == null) throw new IllegalArgumentException("Некорректная VLESS-ссылка");
            String finalName = name.isEmpty() ? extractName(uri) : name;
            profiles.add(new Profile(finalName, uri));
            deduplicateProfilesInPlace();
            saveCachedProfiles(blackListSelected, profiles);
            selected = profiles.size() - 1;
            renderNodes();
            toast("VLESS-сервер добавлен");
        } catch (Exception e) { toast(e.getMessage() == null ? "Не удалось добавить VLESS" : e.getMessage()); }
    }

    private void loadSources(boolean black) {
        sources.clear();
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(black ? KEY_BLACK_SOURCES : KEY_WHITE_SOURCES, null);
        if (raw == null) return;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject o = array.getJSONObject(i);
                String url = o.optString("url", "").trim();
                if (url.isEmpty()) continue;
                sources.add(new Source(o.optString("name", hostName(url)), url));
            }
        } catch (Exception ignored) { }
    }

    private void saveSources() {
        JSONArray array = new JSONArray();
        for (Source source : sources) {
            try { array.put(new JSONObject().put("name", source.name).put("url", source.url)); }
            catch (Exception ignored) { }
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(blackListSelected ? KEY_BLACK_SOURCES : KEY_WHITE_SOURCES, array.toString()).apply();
    }

    private void renderSources() {
        if (sourceList == null) return;
        sourceList.removeAllViews();
        if (sources.isEmpty()) {
            TextView empty = text("Нет подписок. Нажми «+ ДОБАВИТЬ».", 11, MUTED);
            empty.setPadding(dp(6), dp(5), dp(6), dp(4));
            sourceList.addView(empty);
            return;
        }
        for (int i = 0; i < sources.size(); i++) {
            final int index = i;
            Source source = sources.get(i);
            LinearLayout row = panel();
            row.setPadding(dp(10), dp(8), dp(10), dp(8));
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(source.name, 12, WHITE);
            name.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            name.setMaxLines(1);
            name.setEllipsize(TextUtils.TruncateAt.END);
            info.addView(name);
            TextView url = text(hostName(source.url), 9, MUTED);
            url.setMaxLines(1);
            url.setEllipsize(TextUtils.TruncateAt.END);
            info.addView(url);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            TextView result = text(source.testText, 9, source.testColor);
            result.setGravity(Gravity.CENTER);
            row.addView(result, new LinearLayout.LayoutParams(dp(92), -2));
            TextView remove = text("×", 24, MUTED);
            remove.setGravity(Gravity.CENTER);
            remove.setOnClickListener(v -> confirmDeleteSource(index));
            row.addView(remove, new LinearLayout.LayoutParams(dp(36), dp(38)));
            row.setOnClickListener(v -> testOneUrl(index, true));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(5);
            sourceList.addView(row, rp);
        }
    }

    private void confirmDeleteSource(int index) {
        if (index < 0 || index >= sources.size()) return;
        Source s = sources.get(index);
        new AlertDialog.Builder(this).setTitle("Удалить подписку?")
            .setMessage(s.name + "\n" + s.url)
            .setNegativeButton("ОТМЕНА", null)
            .setPositiveButton("УДАЛИТЬ", (d, w) -> {
                sources.remove(index);
                saveSources();
                renderSources();
                refreshSubscriptions(false, false);
            }).show();
    }

    private void refreshSubscriptions(boolean userInitiated, boolean testAfter) {
        if (!loading.compareAndSet(false, true)) return;
        refreshButton.setEnabled(false);
        refreshButton.setText("ОБНОВЛЕНИЕ…");
        statusSub.setText("Загружаем локальные подписки…");
        final boolean black = blackListSelected;
        final List<Source> snapshot = new ArrayList<>(sources);
        executor.execute(() -> {
            List<Profile> merged = new ArrayList<>();
            StringBuilder failures = new StringBuilder();
            for (Source source : snapshot) {
                HttpResult response = httpGet(source.url, 15000, 25000, 65536);
                if (response.error != null || response.code < 200 || response.code >= 300) {
                    String reason = response.error != null ? response.error : "HTTP " + response.code;
                    failures.append(source.name).append(": ").append(reason).append("\n");
                    continue;
                }
                List<Profile> parsed = parseSubscription(response.body);
                if (parsed.isEmpty()) failures.append(source.name).append(": VLESS-ссылки не найдены\n");
                else merged.addAll(parsed);
            }
            merged = deduplicate(merged);
            final List<Profile> result = merged;
            final String failureText = failures.toString().trim();
            runOnUiThread(() -> {
                loading.set(false);
                refreshButton.setEnabled(true);
                refreshButton.setText("ОБНОВИТЬ");
                if (black != blackListSelected) return;
                profiles.clear();
                profiles.addAll(result);
                selected = profiles.isEmpty() ? -1 : 0;
                saveCachedProfiles(black, profiles);
                updateModeButtons();
                renderNodes();
                if (result.isEmpty()) {
                    statusSub.setText(snapshot.isEmpty() ? "Добавь подписку или VLESS-ссылку." : "Серверов не найдено. Проверь URL TEST.");
                    if (userInitiated) showInfo("Обновление", failureText.isEmpty() ? "Подписок нет или формат не содержит VLESS." : failureText);
                } else {
                    statusSub.setText("Загружено серверов: " + result.size());
                    if (userInitiated) toast("Загружено серверов: " + result.size());
                    if (!failureText.isEmpty()) showInfo("Часть источников недоступна", failureText);
                }
                if (testAfter && !sources.isEmpty()) testAllUrls(false);
            });
        });
    }

    private static final String TEST_TELEGRAM = "https://t.me/";
    private static final String TEST_YOUTUBE = "https://www.youtube.com/generate_204";
    private static final String TEST_CHATGPT = "https://chatgpt.com/";

    private static class ServerTestResult {
        boolean ok;
        long totalMs;
        String summary;
        String failure;
    }

    private boolean httpResponded(HttpResult r) {
        // 4xx still proves that HTTPS reached the destination; transport/TLS errors and 5xx fail.
        return r.error == null && r.code >= 100 && r.code < 500;
    }

    private ServerTestResult testServerThroughVpn() {
        ServerTestResult out = new ServerTestResult();
        long started = android.os.SystemClock.elapsedRealtime();
        HttpResult telegram = httpGet(TEST_TELEGRAM, 7000, 9000, 1024);
        if (!httpResponded(telegram)) {
            out.failure = "t.me: " + (telegram.error != null ? telegram.error : "HTTP " + telegram.code);
            return out;
        }
        HttpResult youtube = httpGet(TEST_YOUTUBE, 7000, 9000, 1024);
        if (!httpResponded(youtube)) {
            out.failure = "YouTube: " + (youtube.error != null ? youtube.error : "HTTP " + youtube.code);
            return out;
        }
        HttpResult chatgpt = httpGet(TEST_CHATGPT, 7000, 9000, 2048);
        if (!httpResponded(chatgpt)) {
            out.failure = "ChatGPT: " + (chatgpt.error != null ? chatgpt.error : "HTTP " + chatgpt.code);
            return out;
        }
        out.ok = true;
        out.totalMs = android.os.SystemClock.elapsedRealtime() - started;
        out.summary = "t.me " + telegram.ms + " ms · YouTube " + youtube.ms + " ms · ChatGPT " + chatgpt.ms + " ms";
        return out;
    }

    private void testActiveServerUrl() {
        if (!vpnConnected) {
            precheckAllServers();
            return;
        }
        if (!testingUrls.compareAndSet(false, true)) return;
        testUrlsButton.setEnabled(false);
        testUrlsButton.setText("ТЕСТ…");
        urlTestSummary.setText("Проверяем t.me + YouTube + ChatGPT через VPN…");
        executor.execute(() -> {
            ServerTestResult result = testServerThroughVpn();
            runOnUiThread(() -> {
                testingUrls.set(false);
                testUrlsButton.setEnabled(true);
                testUrlsButton.setText("ПРОВЕРИТЬ СЕРВЕРЫ");
                if (result.ok) {
                    urlTestSummary.setText("OK: " + result.summary);
                    toast("Сервер отвечает через все 3 сервиса");
                } else {
                    urlTestSummary.setText("ОШИБКА: " + result.failure);
                    toast("Проверка: " + result.failure);
                }
            });
        });
    }

    private void precheckAllServers() {
        if (!testingUrls.compareAndSet(false, true)) return;
        if (vpnConnected) {
            testingUrls.set(false);
            toast("Сначала отключи VPN");
            return;
        }
        if (profiles.isEmpty()) {
            testingUrls.set(false);
            toast("Нет серверов для проверки");
            return;
        }
        Intent prepare = VpnService.prepare(this);
        if (prepare != null) {
            pendingVpnConfig = null;
            precheckRunning = true;
            startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
            return;
        }
        executor.execute(this::runPrecheckAllServers);
    }

    private void runPrecheckAllServers() {
        precheckRunning = true;
        final List<Profile> snapshot = new ArrayList<>(profiles);
        final List<Profile> passed = new ArrayList<>();
        int total = snapshot.size();
        for (int i = 0; i < snapshot.size(); i++) {
            Profile profile = snapshot.get(i);
            runOnUiThread(() -> {
                testUrlsButton.setEnabled(false);
                testUrlsButton.setText("ПРОВЕРКА…");
                urlTestSummary.setText("Проверяем: " + profile.name);
                statusSub.setText("Временный туннель → t.me → YouTube → ChatGPT");
            });
            boolean started = startPrecheckTunnel(profile.uri);
            if (!started) {
                continue;
            }
            ServerTestResult result = testServerThroughVpn();
            if (result.ok) {
                passed.add(profile);
                runOnUiThread(() -> urlTestSummary.setText("✓ " + profile.name + " · " + result.summary));
            } else {
                runOnUiThread(() -> urlTestSummary.setText("✕ " + profile.name + " · " + result.failure));
            }
            stopPrecheckTunnel();
            try { Thread.sleep(500); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); break; }
        }
        runOnUiThread(() -> {
            profiles.clear();
            profiles.addAll(passed);
            selected = profiles.isEmpty() ? -1 : 0;
            saveCachedProfiles(blackListSelected, profiles);
            renderNodes();
            precheckRunning = false;
            testingUrls.set(false);
            testUrlsButton.setEnabled(true);
            testUrlsButton.setText("ПРОВЕРИТЬ СЕРВЕРЫ");
            urlTestSummary.setText("Проверка завершена: " + passed.size() + "/" + total + " серверов рабочие");
            statusSub.setText(passed.isEmpty() ? "Рабочих серверов не найдено." : "Оставлены только серверы, отвечающие через t.me, YouTube и ChatGPT.");
            toast("Готово: " + passed.size() + "/" + total + " рабочих серверов");
        });
    }

    private boolean startPrecheckTunnel(String uri) {
        try {
            String config = VlessConfig.fromUri(uri);
            precheckConnected = false;
            precheckWaiting = true;
            Intent intent = new Intent(this, BunkerVpnService.class)
                .setAction(BunkerVpnService.ACTION_START)
                .putExtra(BunkerVpnService.EXTRA_CONFIG, config);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
            long deadline = android.os.SystemClock.elapsedRealtime() + 15000;
            while (precheckWaiting && android.os.SystemClock.elapsedRealtime() < deadline) {
                Thread.sleep(100);
            }
            return precheckConnected;
        } catch (Exception e) {
            return false;
        } finally {
            precheckWaiting = false;
        }
    }

    private void stopPrecheckTunnel() {
        startService(new Intent(this, BunkerVpnService.class).setAction(BunkerVpnService.ACTION_STOP));
        long deadline = android.os.SystemClock.elapsedRealtime() + 7000;
        while (vpnConnected && android.os.SystemClock.elapsedRealtime() < deadline) {
            try { Thread.sleep(100); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); return; }
        }
    }

    private void testAllUrls(boolean userInitiated) {
        if (sources.isEmpty()) {
            toast("Сначала добавь HTTPS-подписку");
            return;
        }
        if (!testingUrls.compareAndSet(false, true)) return;
        testUrlsButton.setEnabled(false);
        testUrlsButton.setText("ТЕСТ…");
        urlTestSummary.setText("Подписки: проверяем HTTPS GET…");
        executor.execute(() -> {
            int ok = 0;
            long total = 0;
            List<String> failed = new ArrayList<>();
            for (int i = 0; i < sources.size(); i++) {
                HttpResult r = httpGet(sources.get(i).url, 7000, 9000, 1024);
                if (r.code >= 200 && r.code < 400) {
                    ok++;
                    total += Math.max(0, r.ms);
                    sources.get(i).testText = "HTTP " + r.code + " · " + r.ms + "ms";
                    sources.get(i).testColor = GREEN;
                } else {
                    String reason = r.error != null ? r.error : "HTTP " + r.code;
                    sources.get(i).testText = reason.length() > 18 ? reason.substring(0, 18) : reason;
                    sources.get(i).testColor = RED;
                    failed.add(sources.get(i).name + ": " + reason);
                }
            }
            final int passed = ok;
            final long avg = passed == 0 ? -1 : total / passed;
            runOnUiThread(() -> {
                testingUrls.set(false);
                testUrlsButton.setEnabled(true);
                testUrlsButton.setText("ПРОВЕРИТЬ СЕРВЕРЫ");
                urlTestSummary.setText("Подписки HTTPS: " + passed + "/" + sources.size() + " OK" + (avg >= 0 ? " · среднее " + avg + " ms" : ""));
                renderSources();
                if (userInitiated) toast("HTTPS GET: " + passed + "/" + sources.size() + " OK");
            });
        });
    }

    private void testOneUrl(int index, boolean userInitiated) {
        if (index < 0 || index >= sources.size()) return;
        Source source = sources.get(index);
        source.testText = "тест…";
        source.testColor = ORANGE;
        renderSources();
        executor.execute(() -> {
            HttpResult r = httpGet(source.url, 7000, 9000, 1024);
            runOnUiThread(() -> {
                if (r.code >= 200 && r.code < 400) {
                    source.testText = "HTTP " + r.code + " · " + r.ms + "ms";
                    source.testColor = GREEN;
                    urlTestSummary.setText("Подписка HTTPS: " + source.name + " · OK");
                } else {
                    source.testText = r.error != null ? r.error : "HTTP " + r.code;
                    source.testColor = RED;
                    urlTestSummary.setText("Подписка HTTPS: " + source.name + " · ошибка");
                }
                renderSources();
                if (userInitiated) toast("HTTPS GET завершён");
            });
        });
    }

    private HttpResult httpGet(String urlText, int connectTimeout, int readTimeout, int maxBytes) {
        HttpResult result = new HttpResult();
        HttpURLConnection connection = null;
        try {
            Uri parsed = Uri.parse(urlText);
            if (!"https".equalsIgnoreCase(parsed.getScheme())) throw new IllegalArgumentException("Нужен HTTPS URL");
            long start = android.os.SystemClock.elapsedRealtime();
            connection = (HttpURLConnection) new URL(urlText).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(connectTimeout);
            connection.setReadTimeout(readTimeout);
            connection.setInstanceFollowRedirects(true);
            connection.setUseCaches(false);
            connection.setRequestProperty("Cache-Control", "no-cache");
            connection.setRequestProperty("User-Agent", "BunkerKot/1.6 Android");
            connection.setRequestProperty("Accept", "text/plain, */*;q=0.9");
            result.code = connection.getResponseCode();
            result.ms = android.os.SystemClock.elapsedRealtime() - start;
            StringBuilder body = new StringBuilder();
            if (result.code >= 200 && result.code < 400) {
                try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream(), StandardCharsets.UTF_8))) {
                    char[] buffer = new char[1024];
                    int read;
                    int total = 0;
                    while ((read = reader.read(buffer)) != -1 && total < maxBytes) {
                        int take = Math.min(read, maxBytes - total);
                        body.append(buffer, 0, take);
                        total += take;
                    }
                }
            }
            result.body = body.toString();
        } catch (Exception e) {
            result.error = friendlyNetworkError(e);
        } finally {
            if (connection != null) connection.disconnect();
        }
        return result;
    }

    private String friendlyNetworkError(Exception e) {
        String m = e.getMessage();
        if (m == null || m.isEmpty()) return e.getClass().getSimpleName();
        if (m.toLowerCase(Locale.ROOT).contains("timeout")) return "timeout";
        return m.length() > 22 ? m.substring(0, 22) : m;
    }

    private void saveCachedProfiles(boolean black, List<Profile> list) {
        try {
            JSONArray array = new JSONArray();
            for (Profile profile : list) array.put(new JSONObject().put("name", profile.name).put("uri", profile.uri));
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(black ? KEY_BLACK_CACHE : KEY_WHITE_CACHE, array.toString()).apply();
        } catch (Exception ignored) { }
    }

    private void restoreCachedProfiles() {
        if (!profiles.isEmpty()) return;
        String raw = getSharedPreferences(PREFS, MODE_PRIVATE).getString(blackListSelected ? KEY_BLACK_CACHE : KEY_WHITE_CACHE, null);
        if (raw == null) return;
        try {
            JSONArray array = new JSONArray(raw);
            for (int i = 0; i < array.length(); i++) {
                JSONObject item = array.getJSONObject(i);
                String uri = item.optString("uri", "");
                if (uri.startsWith("vless://")) profiles.add(new Profile(item.optString("name", extractName(uri)), uri));
            }
            deduplicateProfilesInPlace();
            if (!profiles.isEmpty()) selected = 0;
        } catch (Exception ignored) { }
    }

    private List<Profile> parseSubscription(String source) {
        List<Profile> found = parseLines(source);
        if (!found.isEmpty()) return deduplicate(found);
        String compact = source.replaceAll("\\s+", "");
        try {
            byte[] decoded = android.util.Base64.decode(compact, android.util.Base64.DEFAULT);
            found = parseLines(new String(decoded, StandardCharsets.UTF_8));
        } catch (Exception ignored) { }
        if (found.isEmpty()) {
            try {
                byte[] decoded = android.util.Base64.decode(compact, android.util.Base64.URL_SAFE | android.util.Base64.NO_WRAP | android.util.Base64.NO_PADDING);
                found = parseLines(new String(decoded, StandardCharsets.UTF_8));
            } catch (Exception ignored) { }
        }
        return deduplicate(found);
    }

    private List<Profile> parseLines(String text) {
        List<Profile> result = new ArrayList<>();
        for (String line : text.split("[\\r\\n]+")) {
            String uri = line.trim();
            if (!uri.toLowerCase(Locale.ROOT).startsWith("vless://")) continue;
            try {
                Uri parsed = Uri.parse(uri);
                if (parsed.getHost() == null || parsed.getPort() < 1 || parsed.getUserInfo() == null) continue;
                result.add(new Profile(extractName(uri), uri));
            } catch (Exception ignored) { }
        }
        return result;
    }

    private List<Profile> deduplicate(List<Profile> source) {
        List<Profile> result = new ArrayList<>();
        HashSet<String> seen = new HashSet<>();
        for (Profile p : source) if (seen.add(p.uri)) result.add(p);
        return result;
    }

    private void deduplicateProfilesInPlace() {
        List<Profile> unique = deduplicate(profiles);
        profiles.clear();
        profiles.addAll(unique);
        if (selected >= profiles.size()) selected = profiles.isEmpty() ? -1 : 0;
    }

    private void renderNodes() {
        if (nodeList == null) return;
        nodeList.removeAllViews();
        if (nodeCount != null) nodeCount.setText(profiles.size() + (profiles.size() == 1 ? " сервер" : " серверов"));
        if (cfgName != null) cfgName.setText(selected >= 0 && selected < profiles.size() ? profiles.get(selected).name : "Сервер не выбран");
        if (profiles.isEmpty()) {
            if (emptyHint != null) emptyHint.setText("Список пуст. Добавь подписку или нажми «ОБНОВИТЬ».");
            return;
        }
        if (emptyHint != null) emptyHint.setText("");
        int visible = 0;
        int matches = 0;
        for (int i = 0; i < profiles.size(); i++) {
            Profile profile = profiles.get(i);
            Uri uri = Uri.parse(profile.uri);
            String host = uri.getHost() == null ? "VLESS" : uri.getHost();
            String haystack = (profile.name + " " + host).toLowerCase(Locale.ROOT);
            if (!searchText.isEmpty() && !haystack.contains(searchText)) continue;
            matches++;
            if (visible >= MAX_VISIBLE_NODES) continue;
            final int index = i;
            LinearLayout row = panel();
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(9), dp(8), dp(9));
            row.setBackgroundResource(i == selected ? R.drawable.bg_secondary : R.drawable.bg_panel);
            LinearLayout info = new LinearLayout(this);
            info.setOrientation(LinearLayout.VERTICAL);
            TextView name = text(profile.name, 13, i == selected ? ORANGE : WHITE);
            name.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            name.setMaxLines(1);
            name.setEllipsize(TextUtils.TruncateAt.END);
            info.addView(name);
            TextView hostView = text(host, 10, MUTED);
            hostView.setMaxLines(1);
            hostView.setEllipsize(TextUtils.TruncateAt.END);
            info.addView(hostView);
            row.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            TextView choose = text(i == selected ? "ВЫБРАН" : "ВЫБРАТЬ", 10, i == selected ? ORANGE : MUTED);
            choose.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            choose.setGravity(Gravity.CENTER);
            choose.setPadding(dp(8), dp(8), dp(4), dp(8));
            row.addView(choose, wrap());
            row.setOnClickListener(v -> {
                selected = index;
                cfgName.setText(profiles.get(index).name);
                renderNodes();
            });
            row.setOnLongClickListener(v -> {
                confirmDeleteProfile(index);
                return true;
            });
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
            rp.bottomMargin = dp(6);
            nodeList.addView(row, rp);
            visible++;
        }
        if (matches == 0) {
            TextView empty = text("Ничего не найдено", 13, MUTED);
            empty.setPadding(dp(12), dp(12), dp(12), dp(12));
            nodeList.addView(empty);
        } else if (matches > MAX_VISIBLE_NODES) {
            TextView more = text("Показаны первые " + MAX_VISIBLE_NODES + " из " + matches + ". Уточни поиск.", 11, MUTED);
            more.setPadding(dp(8), dp(8), dp(8), dp(8));
            nodeList.addView(more);
        }
    }

    private void confirmDeleteProfile(int index) {
        if (index < 0 || index >= profiles.size()) return;
        Profile profile = profiles.get(index);
        new AlertDialog.Builder(this)
            .setTitle("Удалить сервер?")
            .setMessage(profile.name + "\n" + hostName(profile.uri))
            .setNegativeButton("ОТМЕНА", null)
            .setPositiveButton("УДАЛИТЬ", (d, w) -> {
                if (index == selected) selected = -1;
                profiles.remove(index);
                if (selected > index) selected--;
                deduplicateProfilesInPlace();
                saveCachedProfiles(blackListSelected, profiles);
                renderNodes();
            }).show();
    }

    private void toggleVpn() {
        if (vpnConnected) {
            startService(new Intent(this, BunkerVpnService.class).setAction(BunkerVpnService.ACTION_STOP));
            return;
        }
        if (selected < 0 || selected >= profiles.size()) {
            toast("Сначала выбери сервер");
            return;
        }
        try {
            pendingVpnConfig = VlessConfig.fromUri(profiles.get(selected).uri);
            Intent prepare = VpnService.prepare(this);
            if (prepare != null) startActivityForResult(prepare, VPN_PERMISSION_REQUEST);
            else startVpnService(pendingVpnConfig);
        } catch (Exception e) {
            showInfo("Не удалось подготовить сервер", e.getMessage() == null ? "Проверь VLESS-конфигурацию." : e.getMessage());
        }
    }

    private void startVpnService(String config) {
        Intent intent = new Intent(this, BunkerVpnService.class)
            .setAction(BunkerVpnService.ACTION_START)
            .putExtra(BunkerVpnService.EXTRA_CONFIG, config);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        status.setText("ПОДКЛЮЧАЕМСЯ");
        status.setTextColor(ORANGE);
        statusSub.setText("Запускаем sing-box…");
        connectButton.setText("ЗАПУСК…");
        connectButton.setEnabled(false);
    }

    private void updateVpnUi(String message) {
        if (status == null || connectButton == null) return;
        connectButton.setEnabled(true);
        if (vpnConnected) {
            status.setText("ПОДКЛЮЧЕНО");
            status.setTextColor(GREEN);
            connectButton.setText("ОТКЛЮЧИТЬ");
            statusSub.setText(message == null ? "VPN-туннель активен." : message);
            heroArtwork.setColorFilter(Color.argb(50, 255, 130, 20), android.graphics.PorterDuff.Mode.SRC_ATOP);
        } else {
            status.setText("НЕ ПОДКЛЮЧЕНО");
            status.setTextColor(ORANGE);
            connectButton.setText("ПОДКЛЮЧИТЬ");
            statusSub.setText(message == null ? "Выбери сервер и нажми на сердце." : message);
            heroArtwork.clearColorFilter();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_PERMISSION_REQUEST) {
            if (resultCode == RESULT_OK && precheckRunning && pendingVpnConfig == null) {
                executor.execute(this::runPrecheckAllServers);
            } else if (resultCode == RESULT_OK && pendingVpnConfig != null) {
                startVpnService(pendingVpnConfig);
            } else {
                precheckRunning = false;
                testingUrls.set(false);
                toast("Для подключения нужно разрешение VPN от Android");
            }
        }
    }

    private String extractName(String uri) {
        try {
            Uri parsed = Uri.parse(uri);
            String fragment = parsed.getFragment();
            if (fragment != null && !fragment.trim().isEmpty()) {
                String name = URLDecoder.decode(fragment, "UTF-8").trim();
                if (!name.isEmpty()) return name;
            }
            return parsed.getHost() == null ? "VLESS сервер" : parsed.getHost();
        } catch (Exception e) { return "VLESS сервер"; }
    }

    private String hostName(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost();
            return host == null ? url : host;
        } catch (Exception e) { return url; }
    }

    private void showMenu() {
        String[] items = {"Добавить VLESS-сервер", "О приложении"};
        new AlertDialog.Builder(this).setTitle("Бункер Кота").setItems(items, (d, which) -> {
            if (which == 0) showAddSourceDialog();
            else showInfo("Бункер Кота · v1.6.1", "Локальные белый и чёрный списки, ручное добавление подписок, HTTPS GET URL TEST и sing-box/libbox. Внешняя встроенная подписка больше не используется.");
        }).show();
    }

    private void showInfo(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("ОК", null).show();
    }

    private LinearLayout panel() { LinearLayout p = new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setBackgroundResource(R.drawable.bg_panel); return p; }
    private TextView label(String s) { TextView t = text(s, 10, ORANGE); t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); return t; }
    private Button secondaryButton(String s) { Button b = new Button(this); b.setText(s); b.setTextSize(10); b.setTextColor(WHITE); b.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackgroundResource(R.drawable.bg_secondary); b.setPadding(dp(5), 0, dp(5), 0); return b; }
    private TextView text(String s, float size, int color) { TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setFontFeatureSettings("kern"); return t; }
    private LinearLayout.LayoutParams wrap() { return new LinearLayout.LayoutParams(-2, -2); }
    private void space(LinearLayout p, int h) { View v = new View(this); p.addView(v, new LinearLayout.LayoutParams(1, dp(h))); }
    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override protected void onDestroy() {
        try { unregisterReceiver(vpnReceiver); } catch (Exception ignored) { }
        executor.shutdownNow();
        scheduler.shutdownNow();
        super.onDestroy();
    }
}
