package ru.bunkerkot.app;
import android.app.*;import android.os.*;import android.graphics.*;import android.view.*;import android.widget.*;
public class MainActivity extends Activity{
 int orange=Color.rgb(255,138,0),bg=Color.rgb(11,11,11),text=Color.rgb(245,245,245),muted=Color.rgb(158,158,158);
 TextView t(String s,float z){TextView v=new TextView(this);v.setText(s);v.setTextColor(text);v.setTextSize(z);v.setPadding(0,5,0,5);return v;}
 public void onCreate(Bundle b){super.onCreate(b);LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(24,28,24,20);r.setBackgroundColor(bg);
 TextView h=t("🐈‍⬛  БУНКЕР КОТА",24);h.setTypeface(Typeface.DEFAULT,Typeface.BOLD);r.addView(h);
 TextView s=t("VPN • Proxy • Telegram",13);s.setTextColor(muted);r.addView(s);
 Space sp=new Space(this);r.addView(sp,new LinearLayout.LayoutParams(1,24));
 LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(20,20,20,20);c.setBackgroundResource(R.drawable.bg_card);
 TextView st=t("Не подключено",22);st.setTextColor(orange);c.addView(st);TextView i=t("Базовая версия приложения. VPN-движок подключим следующим этапом.",14);i.setTextColor(muted);c.addView(i);r.addView(c);
 Space g=new Space(this);r.addView(g,new LinearLayout.LayoutParams(1,18));
 Button x=new Button(this);x.setText("Подключить");x.setAllCaps(false);x.setOnClickListener(v->Toast.makeText(this,"Следующий этап — подключение sing-box",Toast.LENGTH_SHORT).show());r.addView(x,new LinearLayout.LayoutParams(-1,56));
 Button y=new Button(this);y.setText("Импортировать VLESS");y.setAllCaps(false);y.setOnClickListener(v->Toast.makeText(this,"Следующий этап — импорт VLESS",Toast.LENGTH_SHORT).show());LinearLayout.LayoutParams yp=new LinearLayout.LayoutParams(-1,56);yp.topMargin=12;r.addView(y,yp);
 TextView f=t("Бункер Кота • v1.0",12);f.setTextColor(muted);f.setGravity(Gravity.CENTER);r.addView(f);setContentView(r);}
}
