package ru.bunkerkot.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(10, 10, 10);
    private final int PANEL = Color.rgb(22, 22, 22);
    private final int PANEL_2 = Color.rgb(28, 28, 28);
    private final int ORANGE = Color.rgb(255, 145, 35);
    private final int WHITE = Color.rgb(245, 245, 245);
    private final int MUTED = Color.rgb(150, 150, 150);
    private final int GREEN = Color.rgb(78, 190, 112);

    private TextView status;
    private TextView statusSub;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(24));
        scroll.addView(root);

        // Header
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView logo = text("🐈‍⬛", 34, WHITE);
        header.addView(logo, lpWrap());

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.setPadding(dp(12), 0, 0, 0);
        TextView title = text("БУНКЕР КОТА", 25, WHITE);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titles.addView(title);
        titles.addView(text("VPN • Proxy • Telegram", 13, MUTED));
        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));

        TextView menu = text("⋮", 30, MUTED);
        menu.setGravity(Gravity.CENTER);
        header.addView(menu, new LinearLayout.LayoutParams(dp(38), dp(48)));
        root.addView(header);

        addSpace(root, 22);

        // Main status card
        LinearLayout card = panel();
        card.setPadding(dp(20), dp(18), dp(20), dp(18));

        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView dot = text("●", 13, ORANGE);
        row.addView(dot, lpWrap());
        status = text("НЕ ПОДКЛЮЧЕНО", 20, ORANGE);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        status.setPadding(dp(9), 0, 0, 0);
        row.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        TextView badge = text("READY", 11, MUTED);
        badge.setGravity(Gravity.CENTER);
        badge.setBackgroundResource(R.drawable.bg_badge);
        row.addView(badge, new LinearLayout.LayoutParams(dp(64), dp(28)));
        card.addView(row);

        addSpace(card, 10);
        statusSub = text("Выберите конфигурацию и подключитесь к туннелю.", 14, MUTED);
        card.addView(statusSub);
        root.addView(card);

        addSpace(root, 14);

        // Connect button
        Button connect = button("ПОДКЛЮЧИТЬ VPN", ORANGE, Color.BLACK);
        connect.setOnClickListener(v -> {
            status.setText("ГОТОВ К ПОДКЛЮЧЕНИЮ");
            statusSub.setText("VPN-движок будет подключён на следующем этапе.");
            Toast.makeText(this, "Сейчас это интерфейсный прототип", Toast.LENGTH_SHORT).show();
        });
        root.addView(connect, new LinearLayout.LayoutParams(-1, dp(58)));

        addSpace(root, 12);

        // Secondary actions
        LinearLayout actions = new LinearLayout(this);
        actions.setOrientation(LinearLayout.HORIZONTAL);

        Button importBtn = secondaryButton("Импорт VLESS");
        importBtn.setOnClickListener(v -> openFile());
        actions.addView(importBtn, new LinearLayout.LayoutParams(0, dp(52), 1));

        Button pasteBtn = secondaryButton("Вставить ключ");
        pasteBtn.setOnClickListener(v -> Toast.makeText(this, "Поле вставки добавим вместе с импортом VLESS", Toast.LENGTH_SHORT).show());
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(0, dp(52), 1);
        pp.leftMargin = dp(10);
        actions.addView(pasteBtn, pp);
        root.addView(actions);

        addSpace(root, 20);

        // Config card
        LinearLayout cfg = panel();
        cfg.setPadding(dp(18), dp(16), dp(18), dp(16));
        cfg.addView(label("ТЕКУЩАЯ КОНФИГУРАЦИЯ"));
        addSpace(cfg, 8);
        TextView cfgName = text("Конфигурация не выбрана", 16, WHITE);
        cfgName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        cfg.addView(cfgName);
        addSpace(cfg, 5);
        cfg.addView(text("VLESS • Reality • TCP", 13, MUTED));
        root.addView(cfg);

        addSpace(root, 14);

        // Stats row
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.addView(statCard("0", "ПРОФИЛЕЙ"), new LinearLayout.LayoutParams(0, dp(82), 1));
        LinearLayout s2 = statCard("—", "PING");
        LinearLayout.LayoutParams s2p = new LinearLayout.LayoutParams(0, dp(82), 1);
        s2p.leftMargin = dp(10);
        stats.addView(s2, s2p);
        root.addView(stats);

        addSpace(root, 22);

        TextView footer = text("БУНКЕР КОТА  •  v1.0", 12, MUTED);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer);

        setContentView(scroll);
    }

    private void openFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("text/*");
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, 1001);
    }

    private LinearLayout panel() {
        LinearLayout p = new LinearLayout(this);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackgroundResource(R.drawable.bg_panel);
        return p;
    }

    private LinearLayout statCard(String value, String caption) {
        LinearLayout p = panel();
        p.setPadding(dp(16), dp(10), dp(16), dp(10));
        TextView v = text(value, 23, WHITE);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        p.addView(v);
        TextView c = text(caption, 10, MUTED);
        p.addView(c);
        return p;
    }

    private TextView label(String s) {
        return text(s, 10, ORANGE);
    }

    private Button button(String s, int bg, int fg) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(14);
        b.setTextColor(fg);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundResource(R.drawable.bg_button);
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private Button secondaryButton(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextSize(13);
        b.setTextColor(WHITE);
        b.setAllCaps(false);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundResource(R.drawable.bg_secondary);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private TextView text(String s, float size, int color) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private TextView text(String s, float size, int color, int gravity) {
        TextView t = text(s, size, color);
        t.setGravity(gravity);
        return t;
    }

    private void addSpace(LinearLayout p, int h) {
        SpaceView.add(p, dp(h));
    }

    private LinearLayout.LayoutParams lpWrap() {
        return new LinearLayout.LayoutParams(-2, -2);
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private static class SpaceView {
        static void add(LinearLayout p, int height) {
            View v = new View(p.getContext());
            p.addView(v, new LinearLayout.LayoutParams(1, height));
        }
    }
}
