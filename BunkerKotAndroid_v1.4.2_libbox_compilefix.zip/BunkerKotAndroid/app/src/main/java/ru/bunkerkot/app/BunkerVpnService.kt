package ru.bunkerkot.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import android.util.Log
import io.nekohasekai.libbox.*
import java.net.NetworkInterface as JavaNetworkInterface

class BunkerVpnService : VpnService(), PlatformInterface, CommandServerHandler {
    companion object {
        const val ACTION_START = "ru.bunkerkot.app.START_VPN"
        const val ACTION_STOP = "ru.bunkerkot.app.STOP_VPN"
        const val ACTION_STATE = "ru.bunkerkot.app.VPN_STATE"
        const val EXTRA_CONFIG = "config"
        const val EXTRA_MESSAGE = "message"
        const val EXTRA_CONNECTED = "connected"
        private const val NOTIFICATION_ID = 4201
        private const val CHANNEL_ID = "bunker_vpn"
    }

    private var commandServer: CommandServer? = null
    private var tunDescriptor: ParcelFileDescriptor? = null
    @Volatile private var started = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        try {
            val setup = SetupOptions().apply {
                basePath = filesDir.absolutePath
                workingPath = (getExternalFilesDir(null) ?: filesDir).absolutePath
                tempPath = cacheDir.absolutePath
                debug = false
                logMaxLines = 1000
                appVersion = "5"
                appMarketingVersion = "1.4"
            }
            Libbox.setup(setup)
            Libbox.setLocale(java.util.Locale.getDefault().toLanguageTag())
        } catch (e: Exception) {
            Log.e("BunkerVPN", "libbox setup failed", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopTunnel("Отключено")
            return START_NOT_STICKY
        }
        val config = intent?.getStringExtra(EXTRA_CONFIG)
        if (config.isNullOrBlank()) {
            broadcast(false, "Нет конфигурации выбранного профиля")
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, notification("Запуск Бункера Кота…"))
        Thread {
            try {
                if (prepare(this) != null) throw IllegalStateException("Не выдано разрешение Android VPN")
                val server = CommandServer(this, this)
                commandServer = server
                server.start()
                server.startOrReloadService(config, OverrideOptions())
                started = true
                broadcast(true, "Туннель sing-box запущен")
                val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
                manager.notify(NOTIFICATION_ID, notification("VPN активен"))
            } catch (e: Exception) {
                Log.e("BunkerVPN", "start failed", e)
                broadcast(false, e.message ?: "Не удалось запустить VPN")
                stopTunnel(e.message ?: "Ошибка запуска")
            }
        }.start()
        return START_STICKY
    }

    override fun onRevoke() { stopTunnel("Разрешение VPN отозвано"); super.onRevoke() }
    override fun onDestroy() { stopTunnel("Отключено"); super.onDestroy() }

    private fun stopTunnel(message: String) {
        started = false
        try { tunDescriptor?.close() } catch (_: Exception) { }
        tunDescriptor = null
        try { commandServer?.closeService() } catch (_: Exception) { }
        try { commandServer?.close() } catch (_: Exception) { }
        commandServer = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) { }
        broadcast(false, message)
        stopSelf()
    }

    private fun broadcast(connected: Boolean, message: String) {
        sendBroadcast(Intent(ACTION_STATE).setPackage(packageName)
            .putExtra(EXTRA_CONNECTED, connected).putExtra(EXTRA_MESSAGE, message))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Бункер Кота VPN", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val stop = PendingIntent.getService(this, 1, Intent(this, BunkerVpnService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID).setSmallIcon(R.drawable.ic_launcher)
                .setContentTitle("Бункер Кота").setContentText(message).setContentIntent(open)
                .addAction(Notification.Action.Builder(null, "Отключить", stop).build()).setOngoing(started).build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this).setSmallIcon(R.drawable.ic_launcher).setContentTitle("Бункер Кота")
                .setContentText(message).setContentIntent(open).setOngoing(started).build()
        }
    }

    // sing-box PlatformInterface callbacks
    override fun usePlatformAutoDetectInterfaceControl(): Boolean = true
    override fun autoDetectInterfaceControl(fd: Int) { if (!protect(fd)) Log.w("BunkerVPN", "protect(fd) failed") }
    override fun useProcFS(): Boolean = false
    override fun openTun(options: TunOptions): Int {
        if (prepare(this) != null) throw IllegalStateException("VPN-разрешение не получено")
        val builder = Builder().setSession("Бункер Кота").setMtu(options.mtu)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) builder.setMetered(false)
        val v4 = options.inet4Address
        while (v4.hasNext()) { val p = v4.next(); builder.addAddress(p.address(), p.prefix()) }
        val v6 = options.inet6Address
        while (v6.hasNext()) { val p = v6.next(); builder.addAddress(p.address(), p.prefix()) }
        if (options.autoRoute) {
            val dnsMode = options.dnsMode?.value ?: ""
            if (dnsMode != Libbox.DNSModeDisabled) {
                val dns = options.dnsServerAddress
                while (dns.hasNext()) builder.addDnsServer(dns.next())
            }
            val r4 = if (Build.VERSION.SDK_INT >= 33) options.inet4RouteAddress else options.inet4RouteRange
            while (r4.hasNext()) { val p = r4.next(); builder.addRoute(p.address(), p.prefix()) }
            val r6 = if (Build.VERSION.SDK_INT >= 33) options.inet6RouteAddress else options.inet6RouteRange
            while (r6.hasNext()) { val p = r6.next(); builder.addRoute(p.address(), p.prefix()) }
            if (Build.VERSION.SDK_INT >= 33) {
                val x4 = options.inet4RouteExcludeAddress
                while (x4.hasNext()) { val p = x4.next(); builder.excludeRoute(android.net.IpPrefix(java.net.InetAddress.getByName(p.address()), p.prefix())) }
                val x6 = options.inet6RouteExcludeAddress
                while (x6.hasNext()) { val p = x6.next(); builder.excludeRoute(android.net.IpPrefix(java.net.InetAddress.getByName(p.address()), p.prefix())) }
            }
            val include = options.includePackage
            while (include.hasNext()) builder.addAllowedApplication(include.next())
            val exclude = options.excludePackage
            while (exclude.hasNext()) builder.addDisallowedApplication(exclude.next())
        }
        val pfd = builder.establish() ?: throw IllegalStateException("Android не создал VPN-интерфейс")
        tunDescriptor = pfd
        return pfd.fd
    }
    override fun localDNSTransport(): LocalDNSTransport? = null
    override fun findConnectionOwner(ipProtocol: Int, sourceAddress: String, sourcePort: Int, destinationAddress: String, destinationPort: Int): ConnectionOwner {
        throw UnsupportedOperationException("Connection owner lookup is not enabled")
    }
    override fun startDefaultInterfaceMonitor(listener: InterfaceUpdateListener) { }
    override fun closeDefaultInterfaceMonitor(listener: InterfaceUpdateListener) { }
    override fun getInterfaces(): NetworkInterfaceIterator {
        val list = ArrayList<io.nekohasekai.libbox.NetworkInterface>()
        try {
            val all = JavaNetworkInterface.getNetworkInterfaces()
            while (all.hasMoreElements()) {
                val item = all.nextElement()
                if (!item.isUp || item.isLoopback) continue
                val ni = io.nekohasekai.libbox.NetworkInterface()
                ni.name = item.name
                ni.index = item.index
                ni.mtu = try { item.mtu } catch (_: Exception) { 1500 }
                ni.addresses = Strings(item.interfaceAddresses.mapNotNull { a -> a.address?.hostAddress?.let { "$it/${a.networkPrefixLength}" } }.iterator())
                ni.dnsServer = Strings(emptyList<String>().iterator())
                ni.gateway = Strings(emptyList<String>().iterator())
                ni.flags = 0
                ni.type = Libbox.InterfaceTypeOther
                ni.metered = false
                list.add(ni)
            }
        } catch (e: Exception) { Log.w("BunkerVPN", "interfaces unavailable", e) }
        return InterfaceList(list.iterator())
    }
    override fun underNetworkExtension(): Boolean = false
    override fun includeAllNetworks(): Boolean = false
    override fun readWIFIState(): WIFIState? = null
    override fun clearDNSCache() { }
    override fun sendNotification(notification: io.nekohasekai.libbox.Notification) { Log.i("sing-box", notification.body ?: "") }
    override fun cancelNotification(identifier: String, typeID: Int) { }
    override fun startNeighborMonitor(listener: NeighborUpdateListener?) { }
    override fun closeNeighborMonitor(listener: NeighborUpdateListener?) { }
    override fun registerMyInterface(name: String?) { }
    override fun usePlatformShell(): Boolean = false
    override fun checkPlatformShell() { throw UnsupportedOperationException("Shell is not available") }
    override fun openShellSession(user: PlatformUser?, command: String?, environ: StringIterator?, term: String?, rows: Int, cols: Int): ShellSession {
        throw UnsupportedOperationException("Shell is not available")
    }
    override fun lookupUser(username: String?): PlatformUser { throw UnsupportedOperationException("User lookup is not available") }
    override fun lookupSFTPServer(): String { throw UnsupportedOperationException("SFTP is not available") }
    override fun readSystemSSHHostKey(): String { throw UnsupportedOperationException("SSH is not available") }
    override fun tailscaleHostname(): String = "bunker-kot"
    override fun usePlatformBridge(): Boolean = false
    override fun createBridge(options: BridgeOptions?): BridgeSession { throw UnsupportedOperationException("Bridge is not available") }

    // sing-box CommandServerHandler callbacks
    override fun serviceStop() { stopTunnel("Отключено") }
    override fun serviceReload() { }
    override fun getSystemProxyStatus(): SystemProxyStatus = SystemProxyStatus().apply { available = false; enabled = false }
    override fun setSystemProxyEnabled(enabled: Boolean) { }
    override fun triggerNativeCrash() { throw UnsupportedOperationException("Disabled") }
    override fun writeDebugMessage(message: String?) { Log.d("sing-box", message ?: "") }
    override fun connectSSHAgent(): Int = -1

    private class Strings(private val iterator: Iterator<String>) : StringIterator {
        override fun len(): Int = 0
        override fun hasNext(): Boolean = iterator.hasNext()
        override fun next(): String = iterator.next()
    }
    private class InterfaceList(private val iterator: Iterator<io.nekohasekai.libbox.NetworkInterface>) : NetworkInterfaceIterator {
        override fun hasNext(): Boolean = iterator.hasNext()
        override fun next(): io.nekohasekai.libbox.NetworkInterface = iterator.next()
    }
}
