# Бункер Кота Android — v1.2

- Dark UI for Bunker Kot.
- Import VLESS links from text files.
- Paste one or multiple `vless://` links.
- Save profiles locally, select a profile, and remove profiles.
- Duplicate links are skipped.

Important: this version does not yet establish a VPN tunnel. The sing-box/libbox Android service integration is a separate next step; the UI does not pretend that a connection is active.

Build with `gradle :app:assembleDebug` using JDK 17 and Android SDK 35.
